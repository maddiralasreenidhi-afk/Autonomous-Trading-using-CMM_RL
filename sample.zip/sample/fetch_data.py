"""
Fetch both price and news data for a ticker
"""
from cmm_rl.data import HistoricalDataFetcher, NewsFetcher

# Initialize fetchers
price_fetcher = HistoricalDataFetcher()
news_fetcher = NewsFetcher()

# Set parameters
ticker = 'AAPL'
start_date = '2024-01-01'
end_date = '2024-11-21'

print("=" * 70)
print("FETCHING PRICE DATA")
print("=" * 70)
price_df = price_fetcher.fetch(ticker, start_date, end_date)
print(f"\n{price_df.head()}")
print(f"\nPrice data shape: {price_df.shape}")
print(f"Date range: {price_df['timestamp'].min()} to {price_df['timestamp'].max()}")

print("\n" + "=" * 70)
print("FETCHING NEWS DATA")
print("=" * 70)
news_df = news_fetcher.fetch_headlines(ticker, start_date, end_date, limit=50)
print(f"\n{news_df.head()}")
print(f"\nNews data shape: {news_df.shape}")
if not news_df.empty:
    print(f"Date range: {news_df['timestamp'].min()} to {news_df['timestamp'].max()}")
    if 'sentiment' in news_df.columns:
        print(f"Average sentiment: {news_df['sentiment'].mean():.3f}")
else:
    print("No news data fetched")

print("\n" + "=" * 70)
print("DATA FETCH COMPLETE")
print("=" * 70)
print(f"Price records: {len(price_df)}")
print(f"News records: {len(news_df)}")
print(f"\nData saved to:")
print(f"  - data/hist_data/")
print(f"  - data/news_data/")

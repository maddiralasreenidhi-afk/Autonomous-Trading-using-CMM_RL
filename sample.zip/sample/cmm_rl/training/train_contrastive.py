"""
Contrastive Learning Trainer
Trains price and news encoders using NT-Xent loss
"""
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from pathlib import Path
from typing import Optional, Dict, Any
from tqdm import tqdm
from loguru import logger
import argparse
import yaml

from cmm_rl.models import PriceEncoder, NewsEncoder, ContrastiveModel
from cmm_rl.models.price_encoder import normalize_ohlcv
from cmm_rl.training.dataset import ContrastiveDataset, collate_fn, create_train_val_split
from cmm_rl.data import HistoricalDataFetcher, NewsFetcher


class ContrastiveTrainer:
    """Trainer for contrastive learning"""
    
    def __init__(
        self,
        model: ContrastiveModel,
        config: Dict[str, Any],
        device: Optional[torch.device] = None
    ):
        self.model = model
        self.config = config
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        self.model.to(self.device)
        
        # Optimizer
        self.optimizer = optim.AdamW(
            self.model.parameters(),
            lr=config['learning_rate'],
            weight_decay=config.get('weight_decay', 1e-4)
        )
        
        # Learning rate scheduler
        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config['num_epochs'],
            eta_min=config.get('min_lr', 1e-6)
        )
        
        # Tracking
        self.current_epoch = 0
        self.best_val_loss = float('inf')
        self.train_losses = []
        self.val_losses = []
        
        # Checkpoint directory
        self.checkpoint_dir = Path(config.get('checkpoint_dir', './checkpoints'))
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    def train_epoch(self, train_loader: DataLoader) -> float:
        """Train for one epoch"""
        self.model.train()
        
        total_loss = 0.0
        num_batches = 0
        
        pbar = tqdm(train_loader, desc=f"Epoch {self.current_epoch+1} [Train]")
        
        for prices, headlines, tickers in pbar:
            # Move data to device
            prices = prices.to(self.device)
            
            # Normalize prices
            prices = normalize_ohlcv(prices)
            
            # Forward pass
            z_price, z_news = self.model(prices, headlines, device=self.device)
            
            # Compute loss
            loss = self.model.compute_contrastive_loss(z_price, z_news)
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            if self.config.get('grad_clip', 0) > 0:
                nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.config['grad_clip']
                )
            
            self.optimizer.step()
            
            # Track loss
            total_loss += loss.item()
            num_batches += 1
            
            # Update progress bar
            pbar.set_postfix({'loss': f'{loss.item():.4f}'})
        
        avg_loss = total_loss / num_batches
        return avg_loss
    
    def validate(self, val_loader: DataLoader) -> float:
        """Validate the model"""
        self.model.eval()
        
        total_loss = 0.0
        num_batches = 0
        
        with torch.no_grad():
            for prices, headlines, tickers in tqdm(val_loader, desc="Validating"):
                prices = prices.to(self.device)
                prices = normalize_ohlcv(prices)
                
                z_price, z_news = self.model(prices, headlines, device=self.device)
                loss = self.model.compute_contrastive_loss(z_price, z_news)
                
                total_loss += loss.item()
                num_batches += 1
        
        avg_loss = total_loss / num_batches
        return avg_loss
    
    def fit(
        self,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None
    ):
        """Train the model"""
        logger.info(f"Starting training on {self.device}")
        logger.info(f"Training for {self.config['num_epochs']} epochs")
        
        for epoch in range(self.config['num_epochs']):
            self.current_epoch = epoch
            
            # Train
            train_loss = self.train_epoch(train_loader)
            self.train_losses.append(train_loss)
            
            # Validate
            if val_loader is not None:
                val_loss = self.validate(val_loader)
                self.val_losses.append(val_loss)
                
                logger.info(
                    f"Epoch {epoch+1}/{self.config['num_epochs']} - "
                    f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}"
                )
                
                # Save best model
                if val_loss < self.best_val_loss:
                    self.best_val_loss = val_loss
                    self.save_checkpoint('best_model.pth')
                    logger.info(f"New best model saved (val_loss: {val_loss:.4f})")
            else:
                logger.info(f"Epoch {epoch+1}/{self.config['num_epochs']} - Train Loss: {train_loss:.4f}")
            
            # Learning rate schedule
            self.scheduler.step()
            
            # Save periodic checkpoint
            if (epoch + 1) % self.config.get('save_every', 10) == 0:
                self.save_checkpoint(f'checkpoint_epoch_{epoch+1}.pth')
        
        logger.info("Training completed!")
    
    def save_checkpoint(self, filename: str):
        """Save model checkpoint"""
        checkpoint_path = self.checkpoint_dir / filename
        
        torch.save({
            'epoch': self.current_epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'train_losses': self.train_losses,
            'val_losses': self.val_losses,
            'config': self.config
        }, checkpoint_path)
        
        logger.debug(f"Checkpoint saved: {checkpoint_path}")
    
    def load_checkpoint(self, checkpoint_path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.current_epoch = checkpoint['epoch']
        self.train_losses = checkpoint.get('train_losses', [])
        self.val_losses = checkpoint.get('val_losses', [])
        
        logger.info(f"Checkpoint loaded from {checkpoint_path}")


def main():
    """Main training script"""
    parser = argparse.ArgumentParser(description='Train contrastive model')
    parser.add_argument('--config', type=str, required=True, help='Path to config file')
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    logger.info("Loading data...")
    
    # Fetch data
    price_fetcher = HistoricalDataFetcher()
    news_fetcher = NewsFetcher()
    
    tickers = config['data']['tickers']
    start_date = config['data']['start_date']
    end_date = config['data']['end_date']
    
    price_data = {}
    news_data = {}
    
    for ticker in tickers:
        logger.info(f"Fetching data for {ticker}")
        price_data[ticker] = price_fetcher.fetch(ticker, start_date, end_date)
        news_data[ticker] = news_fetcher.fetch_headlines(ticker, start_date, end_date)
    
    # Create dataset
    logger.info("Creating dataset...")
    dataset = ContrastiveDataset(
        price_data=price_data,
        news_data=news_data,
        window_size=config['data']['window_size'],
        stride=config['data']['stride']
    )
    
    # Split train/val
    train_dataset, val_dataset = create_train_val_split(
        dataset,
        val_ratio=config['data']['val_ratio']
    )
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=config['training'].get('num_workers', 0)
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=config['training'].get('num_workers', 0)
    )
    
    # Create model
    logger.info("Creating model...")
    price_encoder = PriceEncoder(
        input_features=5,
        hidden_channels=config['model']['hidden_channels'],
        latent_dim=config['model']['latent_dim'],
        num_layers=config['model']['num_layers'],
        dropout=config['model']['dropout']
    )
    
    news_encoder = NewsEncoder(
        latent_dim=config['model']['latent_dim'],
        bert_model=config['model']['bert_model'],
        freeze_bert=config['model']['freeze_bert'],
        dropout=config['model']['dropout']
    )
    
    model = ContrastiveModel(
        price_encoder=price_encoder,
        news_encoder=news_encoder,
        temperature=config['model']['temperature']
    )
    
    # Create trainer
    trainer = ContrastiveTrainer(
        model=model,
        config=config['training']
    )
    
    # Train
    trainer.fit(train_loader, val_loader)
    
    logger.info("Training completed successfully!")


if __name__ == "__main__":
    main()

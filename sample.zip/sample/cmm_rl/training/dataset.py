"""
Dataset for contrastive learning from price and news data
"""
import torch
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple, Optional
from loguru import logger


class ContrastiveDataset(Dataset):
    """
    Dataset for contrastive learning
    
    Each sample contains:
    - Price sequence (window of OHLCV data)
    - Corresponding news headlines
    """
    
    def __init__(
        self,
        price_data: Dict[str, pd.DataFrame],
        news_data: Dict[str, pd.DataFrame],
        window_size: int = 60,
        stride: int = 1,
        normalize: bool = True
    ):
        """
        Args:
            price_data: Dict mapping ticker -> price DataFrame
            news_data: Dict mapping ticker -> news DataFrame
            window_size: Number of time steps in price window
            stride: Stride for sliding window
            normalize: Whether to normalize prices
        """
        self.window_size = window_size
        self.stride = stride
        self.normalize = normalize
        
        self.samples = []
        self._build_samples(price_data, news_data)
        
        logger.info(f"Created dataset with {len(self.samples)} samples")
    
    def _build_samples(
        self,
        price_data: Dict[str, pd.DataFrame],
        news_data: Dict[str, pd.DataFrame]
    ):
        """Build list of training samples"""
        for ticker in price_data.keys():
            price_df = price_data[ticker]
            news_df = news_data.get(ticker, pd.DataFrame())
            
            if len(price_df) < self.window_size:
                logger.warning(f"Skipping {ticker}: insufficient price data")
                continue
            
            # Create sliding windows
            for i in range(0, len(price_df) - self.window_size + 1, self.stride):
                window_end = i + self.window_size
                
                # Extract price window
                price_window = price_df.iloc[i:window_end]
                
                # Extract relevant news (within the time window)
                if not news_df.empty:
                    start_time = price_window['timestamp'].iloc[0]
                    end_time = price_window['timestamp'].iloc[-1]
                    
                    news_window = news_df[
                        (news_df['timestamp'] >= start_time) &
                        (news_df['timestamp'] <= end_time)
                    ]
                    
                    headlines = news_window['headline'].tolist() if len(news_window) > 0 else []
                else:
                    headlines = []
                
                # Store sample
                self.samples.append({
                    'ticker': ticker,
                    'price_window': price_window,
                    'headlines': headlines,
                    'timestamp': price_window['timestamp'].iloc[-1]
                })
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, List[str], str]:
        """
        Get a sample
        
        Returns:
            prices: (window_size, 5) - OHLCV data
            headlines: List of news headlines
            ticker: Stock ticker
        """
        sample = self.samples[idx]
        
        # Extract OHLCV data
        price_df = sample['price_window']
        prices = price_df[['open', 'high', 'low', 'close', 'volume']].values
        prices = torch.FloatTensor(prices)
        
        # Handle missing values
        if torch.isnan(prices).any():
            prices = torch.nan_to_num(prices, nan=0.0)
        
        headlines = sample['headlines']
        
        # If no headlines, use placeholder
        if len(headlines) == 0:
            headlines = [f"No news available for {sample['ticker']}"]
        
        return prices, headlines, sample['ticker']


def collate_fn(batch: List[Tuple]) -> Tuple[torch.Tensor, List[str], List[str]]:
    """
    Custom collate function for DataLoader
    
    Args:
        batch: List of (prices, headlines, ticker) tuples
    
    Returns:
        prices_batch: (batch_size, window_size, 5)
        headlines_batch: List of headlines (flattened)
        tickers: List of tickers
    """
    prices_list = []
    headlines_batch = []
    tickers = []
    
    for prices, headlines, ticker in batch:
        prices_list.append(prices)
        # Take first headline for simplicity (or could aggregate)
        headlines_batch.append(headlines[0] if headlines else f"No news for {ticker}")
        tickers.append(ticker)
    
    prices_batch = torch.stack(prices_list, dim=0)
    
    return prices_batch, headlines_batch, tickers


def create_train_val_split(
    dataset: ContrastiveDataset,
    val_ratio: float = 0.2,
    shuffle: bool = True
) -> Tuple[Dataset, Dataset]:
    """
    Split dataset into train and validation sets
    
    Args:
        dataset: Full dataset
        val_ratio: Fraction for validation
        shuffle: Whether to shuffle before splitting
    
    Returns:
        train_dataset, val_dataset
    """
    total_size = len(dataset)
    val_size = int(total_size * val_ratio)
    train_size = total_size - val_size
    
    if shuffle:
        indices = torch.randperm(total_size).tolist()
    else:
        indices = list(range(total_size))
    
    train_indices = indices[:train_size]
    val_indices = indices[train_size:]
    
    train_dataset = torch.utils.data.Subset(dataset, train_indices)
    val_dataset = torch.utils.data.Subset(dataset, val_indices)
    
    logger.info(f"Split dataset: {train_size} train, {val_size} val")
    
    return train_dataset, val_dataset


if __name__ == "__main__":
    # Test dataset creation
    from cmm_rl.data import HistoricalDataFetcher, NewsFetcher
    from datetime import datetime, timedelta
    
    # Fetch data
    price_fetcher = HistoricalDataFetcher()
    news_fetcher = NewsFetcher()
    
    tickers = ["RELIANCE", "TCS"]
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
    
    price_data = {}
    news_data = {}
    
    for ticker in tickers:
        price_data[ticker] = price_fetcher.fetch(ticker, start_date, end_date)
        news_data[ticker] = news_fetcher.fetch_headlines(ticker, start_date, end_date)
    
    # Create dataset
    dataset = ContrastiveDataset(
        price_data=price_data,
        news_data=news_data,
        window_size=60,
        stride=5
    )
    
    print(f"Dataset size: {len(dataset)}")
    
    # Test sample
    prices, headlines, ticker = dataset[0]
    print(f"\nSample:")
    print(f"  Ticker: {ticker}")
    print(f"  Prices shape: {prices.shape}")
    print(f"  Headlines: {len(headlines)}")
    print(f"  First headline: {headlines[0]}")

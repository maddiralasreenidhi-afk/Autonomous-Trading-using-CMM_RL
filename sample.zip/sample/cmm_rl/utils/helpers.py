"""
Helper functions
"""
import random
import numpy as np
import torch
from typing import Optional


def set_seed(seed: int = 42):
    """
    Set random seed for reproducibility
    
    Args:
        seed: Random seed
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def get_device(device: Optional[str] = None) -> torch.device:
    """
    Get torch device
    
    Args:
        device: Device string ('cuda', 'cpu', or None for auto)
    
    Returns:
        device: Torch device
    """
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    
    return torch.device(device)


def format_currency(amount: float, currency: str = "₹") -> str:
    """
    Format currency amount
    
    Args:
        amount: Amount to format
        currency: Currency symbol
    
    Returns:
        formatted: Formatted currency string
    """
    if amount >= 10000000:  # 1 Crore
        return f"{currency}{amount/10000000:.2f}Cr"
    elif amount >= 100000:  # 1 Lakh
        return f"{currency}{amount/100000:.2f}L"
    elif amount >= 1000:
        return f"{currency}{amount/1000:.2f}K"
    else:
        return f"{currency}{amount:.2f}"


def count_parameters(model: torch.nn.Module) -> int:
    """
    Count number of trainable parameters in a model
    
    Args:
        model: PyTorch model
    
    Returns:
        num_params: Number of trainable parameters
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_model_size(model: torch.nn.Module) -> float:
    """
    Get model size in MB
    
    Args:
        model: PyTorch model
    
    Returns:
        size_mb: Model size in megabytes
    """
    param_size = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
    
    buffer_size = 0
    for buffer in model.buffers():
        buffer_size += buffer.nelement() * buffer.element_size()
    
    size_mb = (param_size + buffer_size) / 1024**2
    
    return size_mb


if __name__ == "__main__":
    # Test helpers
    set_seed(42)
    print(f"Random number: {random.random()}")
    
    device = get_device()
    print(f"Device: {device}")
    
    amounts = [500, 5000, 50000, 500000, 5000000, 50000000]
    for amount in amounts:
        print(f"{amount:>10} -> {format_currency(amount)}")

"""
Configuration management
"""
import yaml
from pathlib import Path
from typing import Dict, Any
from loguru import logger


def load_config(config_path: str) -> Dict[str, Any]:
    """
    Load configuration from YAML file
    
    Args:
        config_path: Path to config file
    
    Returns:
        config: Configuration dictionary
    """
    config_path = Path(config_path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    logger.info(f"Loaded config from {config_path}")
    
    return config


def save_config(config: Dict[str, Any], save_path: str):
    """
    Save configuration to YAML file
    
    Args:
        config: Configuration dictionary
        save_path: Path to save config
    """
    save_path = Path(save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(save_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    
    logger.info(f"Saved config to {save_path}")


def merge_configs(base_config: Dict[str, Any], override_config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge two configs (override takes precedence)
    
    Args:
        base_config: Base configuration
        override_config: Override configuration
    
    Returns:
        merged_config: Merged configuration
    """
    merged = base_config.copy()
    
    for key, value in override_config.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = merge_configs(merged[key], value)
        else:
            merged[key] = value
    
    return merged


if __name__ == "__main__":
    # Test config loading
    test_config = {
        'model': {
            'latent_dim': 32,
            'hidden_channels': 64
        },
        'training': {
            'batch_size': 32,
            'learning_rate': 0.001
        }
    }
    
    # Save test config
    save_config(test_config, "test_config.yaml")
    
    # Load test config
    loaded_config = load_config("test_config.yaml")
    print(loaded_config)

"""
PPO Training for Trading Agent
"""
import os
import torch
import argparse
import yaml
from pathlib import Path
from datetime import datetime, timedelta
from loguru import logger
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
from stable_baselines3.common.monitor import Monitor

from cmm_rl.rl.environment import TradingEnv
from cmm_rl.data import HistoricalDataFetcher, NewsFetcher
from cmm_rl.models import PriceEncoder, NewsEncoder, ContrastiveModel


class RLTrainer:
    """Trainer for RL trading agent"""
    
    def __init__(self, config: dict):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Create directories
        self.log_dir = Path(config['training']['log_dir'])
        self.checkpoint_dir = Path(config['training']['checkpoint_dir'])
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    def load_encoder_model(self) -> ContrastiveModel:
        """Load pretrained encoder model"""
        logger.info("Loading pretrained encoder model...")
        
        # Create model
        price_encoder = PriceEncoder(
            input_features=5,
            hidden_channels=self.config['encoder']['hidden_channels'],
            latent_dim=self.config['encoder']['latent_dim'],
            num_layers=self.config['encoder']['num_layers']
        )
        
        news_encoder = NewsEncoder(
            latent_dim=self.config['encoder']['latent_dim'],
            bert_model=self.config['encoder']['bert_model'],
            freeze_bert=True
        )
        
        model = ContrastiveModel(
            price_encoder=price_encoder,
            news_encoder=news_encoder
        )
        
        # Load weights
        encoder_checkpoint = self.config['encoder']['checkpoint_path']
        if os.path.exists(encoder_checkpoint):
            checkpoint = torch.load(encoder_checkpoint, map_location=self.device)
            model.load_state_dict(checkpoint['model_state_dict'])
            logger.info(f"Loaded encoder from {encoder_checkpoint}")
        else:
            logger.warning(f"Encoder checkpoint not found: {encoder_checkpoint}")
            logger.warning("Using randomly initialized encoder")
        
        model.eval()
        return model
    
    def create_env(self, encoder_model: ContrastiveModel, is_eval: bool = False):
        """Create trading environment"""
        logger.info("Loading market data...")
        
        price_fetcher = HistoricalDataFetcher()
        news_fetcher = NewsFetcher()
        
        tickers = self.config['data']['tickers']
        
        if is_eval:
            start_date = self.config['data']['eval_start_date']
            end_date = self.config['data']['eval_end_date']
        else:
            start_date = self.config['data']['train_start_date']
            end_date = self.config['data']['train_end_date']
        
        # Fetch data
        price_data = {}
        news_data = {}
        
        for ticker in tickers:
            logger.info(f"Fetching data for {ticker}")
            price_data[ticker] = price_fetcher.fetch(ticker, start_date, end_date)
            news_data[ticker] = news_fetcher.fetch_headlines(ticker, start_date, end_date)
        
        # Create environment
        env = TradingEnv(
            price_data=price_data,
            news_data=news_data,
            encoder_model=encoder_model,
            initial_capital=self.config['trading']['initial_capital'],
            window_size=self.config['data']['window_size'],
            transaction_cost=self.config['trading']['transaction_cost'],
            risk_penalty=self.config['trading']['risk_penalty'],
            use_news=self.config['trading']['use_news']
        )
        
        # Wrap with Monitor for logging
        log_file = self.log_dir / ("eval.log" if is_eval else "train.log")
        env = Monitor(env, str(log_file))
        
        return env
    
    def train(self):
        """Train RL agent"""
        logger.info("Starting RL training...")
        
        # Load encoder
        encoder_model = self.load_encoder_model()
        
        # Create environments
        logger.info("Creating training environment...")
        train_env = DummyVecEnv([lambda: self.create_env(encoder_model, is_eval=False)])
        
        logger.info("Creating evaluation environment...")
        eval_env = DummyVecEnv([lambda: self.create_env(encoder_model, is_eval=True)])
        
        # Create PPO agent
        logger.info("Initializing PPO agent...")
        model = PPO(
            policy="MlpPolicy",
            env=train_env,
            learning_rate=self.config['training']['learning_rate'],
            n_steps=self.config['training']['n_steps'],
            batch_size=self.config['training']['batch_size'],
            n_epochs=self.config['training']['n_epochs'],
            gamma=self.config['training']['gamma'],
            gae_lambda=self.config['training']['gae_lambda'],
            clip_range=self.config['training']['clip_range'],
            ent_coef=self.config['training']['ent_coef'],
            vf_coef=self.config['training']['vf_coef'],
            max_grad_norm=self.config['training']['max_grad_norm'],
            verbose=1,
            tensorboard_log=str(self.log_dir / "tensorboard"),
            device=self.device
        )
        
        # Create callbacks
        checkpoint_callback = CheckpointCallback(
            save_freq=self.config['training']['save_freq'],
            save_path=str(self.checkpoint_dir),
            name_prefix="rl_model"
        )
        
        eval_callback = EvalCallback(
            eval_env,
            best_model_save_path=str(self.checkpoint_dir / "best_model"),
            log_path=str(self.log_dir / "eval"),
            eval_freq=self.config['training']['eval_freq'],
            deterministic=True,
            render=False
        )
        
        # Train
        logger.info(f"Training for {self.config['training']['total_timesteps']} timesteps...")
        model.learn(
            total_timesteps=self.config['training']['total_timesteps'],
            callback=[checkpoint_callback, eval_callback]
        )
        
        # Save final model
        final_path = self.checkpoint_dir / "final_model"
        model.save(final_path)
        logger.info(f"Final model saved to {final_path}")
        
        logger.info("RL training completed!")
        
        return model


def main():
    """Main training script"""
    parser = argparse.ArgumentParser(description='Train RL trading agent')
    parser.add_argument('--config', type=str, required=True, help='Path to config file')
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Create trainer
    trainer = RLTrainer(config)
    
    # Train
    trainer.train()


if __name__ == "__main__":
    main()

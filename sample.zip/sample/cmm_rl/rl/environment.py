"""
Gymnasium Trading Environment for Portfolio Allocation
"""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
import torch
from typing import Dict, Tuple, Optional, Any, List
from loguru import logger

from cmm_rl.models import ContrastiveModel
from cmm_rl.models.price_encoder import normalize_ohlcv


class TradingEnv(gym.Env):
    """
    Trading environment for portfolio allocation
    
    State: [latent_embedding (32), portfolio_weights (n_assets), cash_ratio (1), total_value (1)]
    Action: New portfolio weights (n_assets + 1 for cash)
    Reward: Risk-adjusted returns
    """
    
    metadata = {'render_modes': ['human']}
    
    def __init__(
        self,
        price_data: Dict[str, pd.DataFrame],
        news_data: Dict[str, pd.DataFrame],
        encoder_model: Optional[ContrastiveModel] = None,
        initial_capital: float = 100000.0,
        window_size: int = 60,
        transaction_cost: float = 0.001,
        risk_penalty: float = 0.1,
        use_news: bool = True
    ):
        super().__init__()
        
        self.tickers = list(price_data.keys())
        self.n_assets = len(self.tickers)
        self.price_data = price_data
        self.news_data = news_data
        self.encoder_model = encoder_model
        self.initial_capital = initial_capital
        self.window_size = window_size
        self.transaction_cost = transaction_cost
        self.risk_penalty = risk_penalty
        self.use_news = use_news
        
        # Device for encoder
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if self.encoder_model:
            self.encoder_model.to(self.device)
            self.encoder_model.eval()
        
        # Prepare synchronized data
        self._prepare_data()
        
        # State space: [latent (32), portfolio (n_assets), cash (1), value (1)]
        state_dim = 32 + self.n_assets + 2
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(state_dim,),
            dtype=np.float32
        )
        
        # Action space: portfolio weights (including cash)
        # Actions are logits that will be softmaxed to get weights
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(self.n_assets + 1,),  # +1 for cash
            dtype=np.float32
        )
        
        # Episode state
        self.current_step = 0
        self.portfolio_value = initial_capital
        self.cash = initial_capital
        self.holdings = np.zeros(self.n_assets)
        self.portfolio_weights = np.zeros(self.n_assets + 1)
        self.portfolio_weights[-1] = 1.0  # Start with 100% cash
        
        # Tracking
        self.episode_returns = []
        self.episode_values = []
        
    def _prepare_data(self):
        """Prepare synchronized price data across all assets"""
        # Find common date range
        min_dates = []
        max_dates = []
        
        for ticker in self.tickers:
            df = self.price_data[ticker]
            min_dates.append(df['timestamp'].min())
            max_dates.append(df['timestamp'].max())
        
        self.start_date = max(min_dates)
        self.end_date = min(max_dates)
        
        # Filter and align data
        self.aligned_prices = {}
        for ticker in self.tickers:
            df = self.price_data[ticker]
            df_filtered = df[
                (df['timestamp'] >= self.start_date) &
                (df['timestamp'] <= self.end_date)
            ].reset_index(drop=True)
            self.aligned_prices[ticker] = df_filtered
        
        # Ensure all have same length
        min_len = min(len(df) for df in self.aligned_prices.values())
        for ticker in self.tickers:
            self.aligned_prices[ticker] = self.aligned_prices[ticker].iloc[:min_len]
        
        self.max_steps = min_len - self.window_size
        logger.info(f"Trading environment prepared: {self.max_steps} steps, {self.n_assets} assets")
    
    def _get_state(self) -> np.ndarray:
        """Get current state representation"""
        # Get price windows for all assets
        price_windows = []
        for ticker in self.tickers:
            df = self.aligned_prices[ticker]
            window = df.iloc[self.current_step:self.current_step + self.window_size]
            ohlcv = window[['open', 'high', 'low', 'close', 'volume']].values
            price_windows.append(ohlcv)
        
        # Encode state using contrastive model
        if self.encoder_model:
            # Stack all price windows
            prices_batch = torch.FloatTensor(np.array(price_windows)).to(self.device)
            prices_batch = normalize_ohlcv(prices_batch)
            
            with torch.no_grad():
                if self.use_news:
                    # Get news for current period
                    current_time = self.aligned_prices[self.tickers[0]].iloc[
                        self.current_step + self.window_size - 1
                    ]['timestamp']
                    
                    headlines = []
                    for ticker in self.tickers:
                        news_df = self.news_data.get(ticker, pd.DataFrame())
                        if not news_df.empty:
                            recent_news = news_df[news_df['timestamp'] <= current_time].tail(3)
                            ticker_headlines = recent_news['headline'].tolist()
                            headlines.append(ticker_headlines[0] if ticker_headlines else f"No news for {ticker}")
                        else:
                            headlines.append(f"No news for {ticker}")
                    
                    # Get fused embedding
                    latent = self.encoder_model.get_fused_embedding(
                        prices_batch,
                        headlines,
                        device=self.device,
                        fusion_method="mean"
                    )
                else:
                    # Use only price encoder
                    latent = self.encoder_model.price_encoder(prices_batch)
                
                # Average across assets
                latent = latent.mean(dim=0).cpu().numpy()
        else:
            # Fallback: use simple features
            latent = np.zeros(32)
        
        # Normalize portfolio value
        normalized_value = np.log(self.portfolio_value / self.initial_capital + 1e-8)
        
        # Concatenate: [latent, portfolio_weights, value]
        state = np.concatenate([
            latent,
            self.portfolio_weights,
            [normalized_value]
        ]).astype(np.float32)
        
        return state
    
    def _execute_action(self, action: np.ndarray) -> float:
        """
        Execute portfolio rebalancing
        
        Returns:
            transaction_cost: Cost incurred from rebalancing
        """
        # Convert action to portfolio weights using softmax
        weights = np.exp(action) / np.sum(np.exp(action))
        weights = np.clip(weights, 0, 1)
        weights = weights / weights.sum()  # Ensure sum to 1
        
        # Get current prices
        current_prices = np.array([
            self.aligned_prices[ticker].iloc[self.current_step + self.window_size]['close']
            for ticker in self.tickers
        ])
        
        # Calculate new holdings
        target_values = weights[:-1] * self.portfolio_value  # Exclude cash
        new_holdings = target_values / current_prices
        
        # Calculate transaction cost
        holdings_delta = np.abs(new_holdings - self.holdings)
        cost = np.sum(holdings_delta * current_prices) * self.transaction_cost
        
        # Update portfolio
        self.holdings = new_holdings
        self.cash = weights[-1] * self.portfolio_value
        self.portfolio_weights = weights
        
        return cost
    
    def _calculate_reward(self, prev_value: float, transaction_cost: float) -> float:
        """Calculate reward based on returns and risk"""
        # Portfolio return
        portfolio_return = (self.portfolio_value - prev_value) / prev_value
        
        # Volatility penalty
        if len(self.episode_returns) > 10:
            recent_returns = self.episode_returns[-10:]
            volatility = np.std(recent_returns)
            risk_penalty = self.risk_penalty * volatility
        else:
            risk_penalty = 0
        
        # Reward: return - transaction cost - risk penalty
        reward = portfolio_return - (transaction_cost / prev_value) - risk_penalty
        
        return reward
    
    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one step"""
        prev_value = self.portfolio_value
        
        # Execute action
        transaction_cost = self._execute_action(action)
        
        # Move to next step
        self.current_step += 1
        
        # Calculate new portfolio value
        if self.current_step + self.window_size < len(self.aligned_prices[self.tickers[0]]):
            current_prices = np.array([
                self.aligned_prices[ticker].iloc[self.current_step + self.window_size]['close']
                for ticker in self.tickers
            ])
            
            holdings_value = np.sum(self.holdings * current_prices)
            self.portfolio_value = holdings_value + self.cash - transaction_cost
        
        # Calculate reward
        reward = self._calculate_reward(prev_value, transaction_cost)
        
        # Get new state
        state = self._get_state()
        
        # Check if done
        terminated = self.current_step >= self.max_steps - 1
        truncated = self.portfolio_value <= 0.1 * self.initial_capital  # Stop if lost 90%
        
        # Track metrics
        self.episode_returns.append(reward)
        self.episode_values.append(self.portfolio_value)
        
        info = {
            'portfolio_value': self.portfolio_value,
            'cash': self.cash,
            'holdings_value': np.sum(self.holdings * current_prices) if not terminated else 0,
            'transaction_cost': transaction_cost
        }
        
        return state, reward, terminated, truncated, info
    
    def reset(self, seed: Optional[int] = None, options: Optional[Dict] = None) -> Tuple[np.ndarray, Dict]:
        """Reset environment"""
        super().reset(seed=seed)
        
        # Reset episode
        self.current_step = 0
        self.portfolio_value = self.initial_capital
        self.cash = self.initial_capital
        self.holdings = np.zeros(self.n_assets)
        self.portfolio_weights = np.zeros(self.n_assets + 1)
        self.portfolio_weights[-1] = 1.0
        
        self.episode_returns = []
        self.episode_values = []
        
        # Get initial state
        state = self._get_state()
        info = {}
        
        return state, info
    
    def render(self):
        """Render environment state"""
        if len(self.episode_values) > 0:
            print(f"Step: {self.current_step}/{self.max_steps}")
            print(f"Portfolio Value: ${self.portfolio_value:,.2f}")
            print(f"Return: {(self.portfolio_value / self.initial_capital - 1) * 100:.2f}%")
            print(f"Cash: ${self.cash:,.2f} ({self.cash/self.portfolio_value*100:.1f}%)")
            print(f"Holdings: {self.portfolio_weights[:-1]}")


if __name__ == "__main__":
    # Test environment
    from cmm_rl.data import HistoricalDataFetcher, NewsFetcher
    from datetime import datetime, timedelta
    
    # Fetch data
    price_fetcher = HistoricalDataFetcher()
    news_fetcher = NewsFetcher()
    
    tickers = ["RELIANCE", "TCS"]
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d")
    
    price_data = {ticker: price_fetcher.fetch(ticker, start_date, end_date) for ticker in tickers}
    news_data = {ticker: news_fetcher.fetch_headlines(ticker, start_date, end_date) for ticker in tickers}
    
    # Create environment
    env = TradingEnv(
        price_data=price_data,
        news_data=news_data,
        encoder_model=None,  # Test without encoder
        use_news=False
    )
    
    # Test episode
    state, info = env.reset()
    print(f"State shape: {state.shape}")
    
    for i in range(10):
        action = env.action_space.sample()
        state, reward, terminated, truncated, info = env.step(action)
        print(f"Step {i+1}: Reward={reward:.4f}, Value=${info['portfolio_value']:,.2f}")
        
        if terminated or truncated:
            break

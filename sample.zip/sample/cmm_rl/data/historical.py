"""
Historical price data fetcher using Twelve Data API
"""
import os
import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from loguru import logger
from pathlib import Path
from dotenv import load_dotenv


class HistoricalDataFetcher:
    """Fetch historical OHLCV data from Twelve Data API"""
    
    BASE_URL = "https://api.twelvedata.com"
    
    def __init__(
        self,
        api_key: Optional[str] = None
    ):
        # Ensure .env is loaded when used as a module or script
        try:
            load_dotenv()
        except Exception:
            pass

        self.api_key = api_key or os.getenv("TWELVE_DATA_API_KEY")
        
        if not self.api_key:
            logger.warning("Twelve Data API key not found. Using mock data mode.")
        else:
            logger.info("Twelve Data API initialized")
    
    def fetch(
        self,
        ticker: str,
        start_date: str,
        end_date: str,
        interval: str = "1day"
    ) -> pd.DataFrame:
        """
        Fetch historical price data from Twelve Data API
        
        Args:
            ticker: Stock symbol (e.g., 'AAPL', 'RELIANCE' for NSE)
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            interval: Data interval ('1min', '5min', '15min', '30min', '1h', '1day', '1week', '1month')
        
        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        logger.info(f"Fetching historical data for {ticker} from {start_date} to {end_date}")
        
        if not self.api_key:
            logger.warning("API key not found, using mock data")
            df = self._generate_mock_data(ticker, start_date, end_date, interval)
            self._save_history_to_disk(df, ticker, start_date, end_date, interval, source="mock")
            return df
        
        try:
            # Build API URL
            url = f"{self.BASE_URL}/time_series"
            params = {
                'symbol': ticker,
                'interval': interval,
                'outputsize': 5000,
                'apikey': self.api_key,
                'format': 'JSON'
            }
            
            logger.debug(f"Fetching from Twelve Data with params: {params}")
            
            response = requests.get(url, params=params)
            response_data = response.json()
            
            # Check if the response contains an error or the expected data
            if 'values' not in response_data:
                logger.warning(f"API error for {ticker}. Response: {response_data}")
                logger.warning("Using mock data fallback")
                df = self._generate_mock_data(ticker, start_date, end_date, interval)
                self._save_history_to_disk(df, ticker, start_date, end_date, interval, source="mock")
                return df
            
            data = response_data['values']
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            df['timestamp'] = pd.to_datetime(df['datetime']).dt.tz_localize(None)  # Remove timezone to match news data
            df = df.drop('datetime', axis=1)
            df = df.sort_values('timestamp').reset_index(drop=True)
            
            # Convert to float
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Filter by date range
            df = df[(df['timestamp'] >= start_date) & (df['timestamp'] <= end_date)]
            
            # Reorder columns
            df = df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]
            
            logger.info(f"Fetched {len(df)} records for {ticker}")
            self._save_history_to_disk(df, ticker, start_date, end_date, interval)
            return df
        
        except Exception as e:
            logger.error(f"Twelve Data API request failed: {e}")
            logger.warning("Falling back to mock data")
            df = self._generate_mock_data(ticker, start_date, end_date, interval)
            self._save_history_to_disk(df, ticker, start_date, end_date, interval, source="mock")
            return df
    
    def fetch_multiple(
        self,
        tickers: List[str],
        start_date: str,
        end_date: str,
        interval: str = "1day"
    ) -> Dict[str, pd.DataFrame]:
        """Fetch historical data for multiple tickers"""
        results = {}
        for ticker in tickers:
            results[ticker] = self.fetch(ticker, start_date, end_date, interval)
        return results
    
    def _generate_mock_data(
        self,
        ticker: str,
        start_date: str,
        end_date: str,
        interval: str
    ) -> pd.DataFrame:
        """Generate mock data for testing"""
        logger.warning(f"Generating mock data for {ticker}")
        
        import numpy as np
        
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        
        # Generate date range based on interval
        if interval in ["1day", "ONE_DAY"]:
            timestamps = pd.date_range(start, end, freq='D')
        elif interval in ["1h", "1hour", "ONE_HOUR"]:
            timestamps = pd.date_range(start, end, freq='H')
        elif interval in ["1week", "1wk"]:
            timestamps = pd.date_range(start, end, freq='W')
        else:
            timestamps = pd.date_range(start, end, freq='D')
        
        n = len(timestamps)
        
        # Generate realistic-looking price data
        base_price = 1000
        returns = np.random.randn(n) * 0.02  # 2% daily volatility
        prices = base_price * (1 + returns).cumprod()
        
        df = pd.DataFrame({
            'timestamp': timestamps,
            'open': prices * (1 + np.random.randn(n) * 0.005),
            'high': prices * (1 + np.abs(np.random.randn(n)) * 0.01),
            'low': prices * (1 - np.abs(np.random.randn(n)) * 0.01),
            'close': prices,
            'volume': np.random.randint(100000, 1000000, n)
        })
        
        return df

    def _save_history_to_disk(
        self,
        df: pd.DataFrame,
        ticker: str,
        start_date: str,
        end_date: str,
        interval: str,
        source: str = "api"
    ):
        """Save historical data to data/hist_data as CSV"""
        try:
            base_dir = Path("data") / "hist_data"
            base_dir.mkdir(parents=True, exist_ok=True)
            safe_ticker = ticker.upper().replace("/", "_")
            file_name = f"{safe_ticker}_{start_date}_{end_date}_{interval}_{source}.csv"
            path = base_dir / file_name
            # Ensure timestamp is ISO formatted when saving
            df_to_save = df.copy()
            if not pd.api.types.is_datetime64_any_dtype(df_to_save['timestamp']):
                df_to_save['timestamp'] = pd.to_datetime(df_to_save['timestamp'], errors='coerce')
            df_to_save.to_csv(path, index=False)
            logger.info(f"Saved historical data to {path}")
        except Exception as e:
            logger.warning(f"Failed to save historical data: {e}")


if __name__ == "__main__":
    # Test the fetcher
    fetcher = HistoricalDataFetcher()
    
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
    
    df = fetcher.fetch("TITAN", start_date, end_date)
    print(df.head())
    print(f"\nShape: {df.shape}")

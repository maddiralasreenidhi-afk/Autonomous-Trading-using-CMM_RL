"""
Live market data feed - DEPRECATED
Note: Twelve Data API does not support WebSocket streaming for free tier.
For live data, use polling with the HistoricalDataFetcher.fetch() method.
"""
import os
import time
from queue import Queue
from typing import Optional, Callable, Dict, Any
from loguru import logger


class LiveMarketFeed:
    """
    DEPRECATED: Live feed is not available with Twelve Data free tier.
    Use HistoricalDataFetcher for latest data instead.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        callback: Optional[Callable] = None
    ):
        logger.warning("LiveMarketFeed is deprecated. Twelve Data free tier doesn't support live streaming.")
        logger.warning("Use HistoricalDataFetcher.fetch() to get latest data instead.")
        self.callback = callback
        self.data_queue = Queue()
        self.subscribed_tickers = set()
    
    def connect(self):
        """Deprecated - no-op"""
        logger.warning("Live feed not available. Use HistoricalDataFetcher instead.")
    
    def subscribe(self, ticker: str):
        """Deprecated - no-op"""
        logger.warning(f"Cannot subscribe to {ticker}. Use HistoricalDataFetcher instead.")
    
    def unsubscribe(self, ticker: str):
        """Deprecated - no-op"""
        pass
    
    def get_latest(self, timeout: float = 1.0) -> Optional[Dict[str, Any]]:
        """Deprecated - returns None"""
        return None
    
    def close(self):
        """Deprecated - no-op"""
        pass
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


"""
Instruments helper - DEPRECATED
Note: This module was specific to AngelOne API.
Twelve Data API uses simple symbol strings (e.g., 'AAPL', 'GOOGL').
"""
from typing import Optional
from loguru import logger


def resolve_token_nse_equity(ticker: str) -> Optional[str]:
    """
    DEPRECATED: This was used for AngelOne numeric tokens.
    Twelve Data API uses symbol strings directly.
    """
    logger.warning("resolve_token_nse_equity is deprecated. Use ticker symbols directly with Twelve Data API.")
    return None


def load_token_map() -> dict:
    """DEPRECATED: Returns empty dict"""
    return {}


def refresh_scrip_master():
    """DEPRECATED: No-op"""
    logger.warning("refresh_scrip_master is deprecated. Not needed for Twelve Data API.")
                    mapping[item['symbol'].upper()] = str(item.get('token', ''))
            return mapping
        except Exception as e:
            logger.warning(f"Failed to read OpenAPIScripMaster.json: {e}")
    
    return {}


def resolve_token_nse_equity(ticker: str) -> Optional[str]:
    """Resolve numeric token for an NSE equity ticker via local token map.
    Returns None if not found.
    """
    token_map = load_token_map()
    tradingsymbol = f"{ticker.upper()}-EQ"
    token = token_map.get(tradingsymbol.upper())
    if token:
        return token
    else:
        logger.warning(
            "Instrument token not found locally for %s. "
            "Run scripts/fetch_instruments.py to download the scrip master.",
            tradingsymbol,
        )
        return None

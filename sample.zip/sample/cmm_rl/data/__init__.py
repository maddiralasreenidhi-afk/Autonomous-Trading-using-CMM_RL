"""
Data module for fetching Indian market data
"""
from .historical import HistoricalDataFetcher
from .live_feed import LiveMarketFeed
from .news import NewsFetcher

__all__ = ['HistoricalDataFetcher', 'LiveMarketFeed', 'NewsFetcher']

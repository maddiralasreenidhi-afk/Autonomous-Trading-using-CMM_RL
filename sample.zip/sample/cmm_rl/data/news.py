"""
News headline fetcher and sentiment analyzer using EODHD API
"""
import os
import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, List, Dict
from loguru import logger
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


class NewsFetcher:
    """
    Fetch news headlines and sentiment using EODHD API
    """
    
    NEWS_URL = "https://eodhd.com/api/news"
    SENTIMENT_URL = "https://eodhd.com/api/sentiments"
    
    def __init__(
        self,
        api_key: Optional[str] = None
    ):
        self.api_key = api_key or os.getenv("EODHD_API_KEY")
        
        if not self.api_key:
            logger.warning("EODHD API key not found. Will use mock news data.")
        else:
            logger.info("EODHD API initialized")
        
        self.session = requests.Session()
    
    def fetch_headlines(
        self,
        ticker: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100
    ) -> pd.DataFrame:
        """
        Fetch news headlines and sentiment for a ticker from EODHD API
        
        Args:
            ticker: Stock symbol (e.g., 'AAPL', 'GOOGL')
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            limit: Maximum number of headlines to fetch (used for mock data)
        
        Returns:
            DataFrame with columns: timestamp, headline, source, url, sentiment
        """
        if not end_date:
            end_date = datetime.now().strftime("%Y-%m-%d")
        
        if not start_date:
            start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        
        logger.info(f"Fetching news for {ticker} from {start_date} to {end_date}")
        
        if not self.api_key:
            logger.warning("API key not found, using mock data")
            df = self._generate_mock_news(ticker, start_date, end_date, limit)
            self._save_news_to_disk(df, ticker, start_date, end_date, source="mock")
            return df
        
        try:
            # Add .US suffix if not present (EODHD format)
            symbol = ticker if '.' in ticker else f"{ticker}.US"
            
            # Fetch news data
            news_params = {
                "s": symbol,
                "from": start_date,
                "to": end_date,
                "api_token": self.api_key,
                "fmt": "json"
            }
            
            logger.debug(f"Fetching news from EODHD with params: {news_params}")
            
            news_response = self.session.get(self.NEWS_URL, params=news_params)
            news_response.raise_for_status()
            news_data = news_response.json()
            
            # Filter news where the symbol is explicitly mentioned
            filtered_news = [item for item in news_data if symbol in item.get("symbols", [])]
            
            if not filtered_news:
                logger.warning(f"No news data returned for {ticker}")
                df = self._generate_mock_news(ticker, start_date, end_date, limit)
                self._save_news_to_disk(df, ticker, start_date, end_date, source="mock")
                return df
            
            # Parse news articles
            articles = []
            for item in filtered_news:
                timestamp = pd.to_datetime(item.get('date'))
                # Remove timezone if present
                if timestamp.tzinfo is not None:
                    timestamp = timestamp.tz_localize(None)
                articles.append({
                    'timestamp': timestamp,
                    'headline': item.get('title', ''),
                    'source': item.get('link', '').split('/')[2] if item.get('link') else 'N/A',
                    'url': item.get('link', ''),
                    'sentiment': self._normalize_sentiment(item.get('sentiment', {}))
                })
            
            df = pd.DataFrame(articles)
            # Ensure timestamp column is timezone-naive
            if df['timestamp'].dt.tz is not None:
                df['timestamp'] = df['timestamp'].dt.tz_localize(None)
            df = df.sort_values('timestamp').reset_index(drop=True)
            
            # Fetch sentiment data for trend analysis
            sentiment_df = self._fetch_sentiment_data(symbol, start_date, end_date)
            if sentiment_df is not None and not sentiment_df.empty:
                # Merge sentiment scores with news (join on date)
                df['date_only'] = df['timestamp'].dt.date
                sentiment_df['date_only'] = sentiment_df['date'].dt.date
                df = df.merge(
                    sentiment_df[['date_only', 'normalized']], 
                    on='date_only', 
                    how='left',
                    suffixes=('', '_daily')
                )
                df = df.drop('date_only', axis=1)
                # Use daily sentiment if article sentiment is missing
                df['sentiment'] = df['sentiment'].fillna(df.get('normalized', 0.0))
                if 'normalized' in df.columns:
                    df = df.drop('normalized', axis=1)
            
            logger.info(f"Fetched {len(df)} news articles for {ticker}")
            self._save_news_to_disk(df, ticker, start_date, end_date, source="api")
            return df
            
        except Exception as e:
            logger.error(f"EODHD API request failed: {e}")
            logger.warning("Falling back to mock data")
            df = self._generate_mock_news(ticker, start_date, end_date, limit)
            self._save_news_to_disk(df, ticker, start_date, end_date, source="mock")
            return df
    
    def _fetch_sentiment_data(
        self,
        symbol: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """Fetch sentiment data from EODHD API"""
        try:
            sentiment_params = {
                "s": symbol,
                "from": start_date,
                "to": end_date,
                "api_token": self.api_key,
                "fmt": "json"
            }
            
            logger.debug(f"Fetching sentiment data from EODHD")
            
            sentiment_response = self.session.get(self.SENTIMENT_URL, params=sentiment_params)
            sentiment_response.raise_for_status()
            sentiment_data = sentiment_response.json()
            
            if symbol in sentiment_data:
                sentiment_df = pd.DataFrame(sentiment_data[symbol])
                sentiment_df['date'] = pd.to_datetime(sentiment_df['date'])
                # Remove timezone if present
                if sentiment_df['date'].dt.tz is not None:
                    sentiment_df['date'] = sentiment_df['date'].dt.tz_localize(None)
                logger.info(f"Fetched {len(sentiment_df)} sentiment records")
                return sentiment_df
            else:
                logger.warning(f"No sentiment data found for {symbol}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to fetch sentiment data: {e}")
            return None
    
    def _normalize_sentiment(self, sentiment_dict: dict) -> float:
        """
        Normalize EODHD sentiment to a score between -1 and 1
        
        Args:
            sentiment_dict: Dictionary with sentiment scores
            
        Returns:
            Normalized sentiment score (-1 to 1)
        """
        if not sentiment_dict:
            return 0.0
        
        # EODHD provides polarity, neg, neu, pos
        # Use polarity if available, otherwise calculate from pos/neg
        if 'polarity' in sentiment_dict:
            return float(sentiment_dict['polarity'])
        
        pos = float(sentiment_dict.get('pos', 0))
        neg = float(sentiment_dict.get('neg', 0))
        
        # Calculate sentiment as (positive - negative)
        return pos - neg
    
    def fetch_latest(self, ticker: str, limit: int = 10) -> List[Dict]:
        """Fetch latest news headlines"""
        df = self.fetch_headlines(ticker, limit=limit)
        if not df.empty:
            return df.to_dict('records')
        return []
    
    def _generate_mock_news(
        self,
        ticker: str,
        start_date: str,
        end_date: str,
        limit: int
    ) -> pd.DataFrame:
        """Generate mock news data for testing"""
        logger.warning(f"Generating mock news for {ticker}")
        
        import random
        
        headlines_templates = [
            f"{ticker} reports strong quarterly earnings",
            f"{ticker} announces new product launch",
            f"Market analysts upgrade {ticker} rating",
            f"{ticker} CEO discusses growth strategy",
            f"{ticker} stock surges on positive sentiment",
            f"Regulatory approval for {ticker} expansion",
            f"{ticker} faces market headwinds",
            f"Investors bullish on {ticker} prospects",
            f"{ticker} announces dividend increase",
            f"New partnership boosts {ticker} outlook"
        ]
        
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        
        timestamps = pd.date_range(start, end, periods=min(limit, 50))
        
        data = []
        for ts in timestamps:
            data.append({
                'timestamp': ts,
                'headline': random.choice(headlines_templates),
                'source': random.choice(['Financial Times', 'Bloomberg', 'Reuters', 'CNBC']),
                'url': f'https://example.com/news/{random.randint(1000, 9999)}',
                'sentiment': random.uniform(-1.0, 1.0)  # Random sentiment score
            })
        
        return pd.DataFrame(data)

    def _save_news_to_disk(
        self,
        df: pd.DataFrame,
        ticker: str,
        start_date: str,
        end_date: str,
        source: str = "api"
    ):
        """Save news headlines to data/news_data as CSV"""
        try:
            base_dir = Path("data") / "news_data"
            base_dir.mkdir(parents=True, exist_ok=True)
            safe_ticker = ticker.upper().replace("/", "_")
            file_name = f"{safe_ticker}_{start_date}_{end_date}_{source}.csv"
            path = base_dir / file_name
            df_to_save = df.copy()
            if 'timestamp' in df_to_save.columns:
                df_to_save['timestamp'] = pd.to_datetime(df_to_save['timestamp'], errors='coerce')
            df_to_save.to_csv(path, index=False)
            logger.info(f"Saved news data to {path}")
        except Exception as e:
            logger.warning(f"Failed to save news data: {e}")


class NewsCache:
    """Cache news data to reduce API calls"""
    
    def __init__(self, cache_dir: str = "./data/news_cache"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
    
    def get_cache_path(self, ticker: str, date: str) -> str:
        """Get cache file path for ticker and date"""
        return os.path.join(self.cache_dir, f"{ticker}_{date}.parquet")
    
    def save(self, ticker: str, date: str, df: pd.DataFrame):
        """Save news data to cache"""
        path = self.get_cache_path(ticker, date)
        df.to_parquet(path)
        logger.debug(f"Cached news for {ticker} on {date}")
    
    def load(self, ticker: str, date: str) -> Optional[pd.DataFrame]:
        """Load news data from cache"""
        path = self.get_cache_path(ticker, date)
        if os.path.exists(path):
            logger.debug(f"Loading cached news for {ticker} on {date}")
            return pd.read_parquet(path)
        return None
    
    def is_cached(self, ticker: str, date: str) -> bool:
        """Check if data is cached"""
        return os.path.exists(self.get_cache_path(ticker, date))


if __name__ == "__main__":
    # Test the news fetcher
    fetcher = NewsFetcher()
    
    # Test with date range matching historical data
    df = fetcher.fetch_headlines("AAPL", start_date="2024-01-01", end_date="2024-01-31", limit=50)
    print(df.head())
    print(f"\nShape: {df.shape}")
    print(f"\nDate range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    # Test latest news
    latest = fetcher.fetch_latest("AAPL", limit=5)
    print(f"\nLatest news: {len(latest)} articles")
    for article in latest[:3]:
        print(f"- {article['headline']}")

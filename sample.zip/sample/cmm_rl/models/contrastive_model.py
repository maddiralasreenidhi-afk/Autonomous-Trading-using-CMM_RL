"""
Contrastive Model combining Price and News encoders
Implements NT-Xent (Normalized Temperature-scaled Cross Entropy) loss
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional
from .price_encoder import PriceEncoder
from .news_encoder import NewsEncoder


class ContrastiveModel(nn.Module):
    """
    Multi-modal contrastive learning model
    
    Learns joint representations by maximizing agreement between
    price and news encodings for the same time period
    """
    
    def __init__(
        self,
        price_encoder: PriceEncoder,
        news_encoder: NewsEncoder,
        temperature: float = 0.07,
        use_projection_head: bool = True
    ):
        super().__init__()
        
        self.price_encoder = price_encoder
        self.news_encoder = news_encoder
        self.temperature = temperature
        
        # Ensure both encoders have same latent dimension
        assert price_encoder.latent_dim == news_encoder.latent_dim, \
            "Price and news encoders must have same latent dimension"
        
        self.latent_dim = price_encoder.latent_dim
        
        # Optional projection heads for contrastive learning
        if use_projection_head:
            self.price_projection = nn.Sequential(
                nn.Linear(self.latent_dim, self.latent_dim),
                nn.ReLU(),
                nn.Linear(self.latent_dim, self.latent_dim)
            )
            self.news_projection = nn.Sequential(
                nn.Linear(self.latent_dim, self.latent_dim),
                nn.ReLU(),
                nn.Linear(self.latent_dim, self.latent_dim)
            )
        else:
            self.price_projection = nn.Identity()
            self.news_projection = nn.Identity()
    
    def encode_price(self, prices: torch.Tensor) -> torch.Tensor:
        """Encode price data"""
        z_price = self.price_encoder(prices)
        return self.price_projection(z_price)
    
    def encode_news(self, headlines: list, device: Optional[torch.device] = None) -> torch.Tensor:
        """Encode news headlines"""
        z_news = self.news_encoder(headlines, device=device)
        return self.news_projection(z_news)
    
    def forward(
        self,
        prices: torch.Tensor,
        headlines: list,
        device: Optional[torch.device] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass
        
        Args:
            prices: (batch, seq_len, features) - price data
            headlines: List of headlines (length = batch)
            device: Device to use
        
        Returns:
            z_price: (batch, latent_dim) - price embeddings
            z_news: (batch, latent_dim) - news embeddings
        """
        z_price = self.encode_price(prices)
        z_news = self.encode_news(headlines, device=device)
        
        return z_price, z_news
    
    def compute_contrastive_loss(
        self,
        z_price: torch.Tensor,
        z_news: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute NT-Xent contrastive loss
        
        Args:
            z_price: (batch, latent_dim) - normalized price embeddings
            z_news: (batch, latent_dim) - normalized news embeddings
        
        Returns:
            loss: Scalar contrastive loss
        """
        batch_size = z_price.shape[0]
        
        # Normalize embeddings
        z_price = F.normalize(z_price, dim=1)
        z_news = F.normalize(z_news, dim=1)
        
        # Compute similarity matrix
        # (batch, batch) - similarity between all price-news pairs
        similarity_matrix = torch.matmul(z_price, z_news.T) / self.temperature
        
        # Create labels: diagonal elements are positive pairs
        labels = torch.arange(batch_size, device=z_price.device)
        
        # Compute cross-entropy loss in both directions
        loss_price_to_news = F.cross_entropy(similarity_matrix, labels)
        loss_news_to_price = F.cross_entropy(similarity_matrix.T, labels)
        
        # Average both directions
        loss = (loss_price_to_news + loss_news_to_price) / 2
        
        return loss
    
    def get_fused_embedding(
        self,
        prices: torch.Tensor,
        headlines: list,
        device: Optional[torch.device] = None,
        fusion_method: str = "concat"
    ) -> torch.Tensor:
        """
        Get fused embedding from both modalities
        
        Args:
            prices: (batch, seq_len, features) - price data
            headlines: List of headlines
            device: Device to use
            fusion_method: 'concat', 'mean', or 'weighted'
        
        Returns:
            z_fused: Fused embedding
        """
        z_price = self.price_encoder(prices)
        z_news = self.news_encoder(headlines, device=device)
        
        if fusion_method == "concat":
            return torch.cat([z_price, z_news], dim=-1)
        elif fusion_method == "mean":
            return (z_price + z_news) / 2
        elif fusion_method == "weighted":
            # Learnable weighted fusion
            alpha = torch.sigmoid(self.fusion_weight)
            return alpha * z_price + (1 - alpha) * z_news
        else:
            raise ValueError(f"Unknown fusion method: {fusion_method}")


def nt_xent_loss(
    embeddings1: torch.Tensor,
    embeddings2: torch.Tensor,
    temperature: float = 0.07
) -> torch.Tensor:
    """
    Standalone NT-Xent loss function
    
    Args:
        embeddings1: (batch, dim) - first set of embeddings
        embeddings2: (batch, dim) - second set of embeddings
        temperature: Temperature parameter
    
    Returns:
        loss: Contrastive loss
    """
    batch_size = embeddings1.shape[0]
    
    # Normalize
    embeddings1 = F.normalize(embeddings1, dim=1)
    embeddings2 = F.normalize(embeddings2, dim=1)
    
    # Similarity matrix
    similarity = torch.matmul(embeddings1, embeddings2.T) / temperature
    
    # Labels
    labels = torch.arange(batch_size, device=embeddings1.device)
    
    # Cross-entropy in both directions
    loss1 = F.cross_entropy(similarity, labels)
    loss2 = F.cross_entropy(similarity.T, labels)
    
    return (loss1 + loss2) / 2


if __name__ == "__main__":
    # Test contrastive model
    from .price_encoder import normalize_ohlcv
    
    batch_size = 4
    seq_len = 60
    latent_dim = 32
    
    # Create encoders
    price_encoder = PriceEncoder(
        input_features=5,
        latent_dim=latent_dim
    )
    
    news_encoder = NewsEncoder(
        latent_dim=latent_dim,
        freeze_bert=True
    )
    
    # Create contrastive model
    model = ContrastiveModel(
        price_encoder=price_encoder,
        news_encoder=news_encoder,
        temperature=0.07
    )
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    
    # Create sample data
    prices = torch.randn(batch_size, seq_len, 5) * 10 + 100
    prices = normalize_ohlcv(prices).to(device)
    
    headlines = [
        "Strong quarterly earnings exceed expectations",
        "Market volatility increases amid uncertainty",
        "New product launch drives growth",
        "Regulatory approval boosts outlook"
    ]
    
    # Forward pass
    z_price, z_news = model(prices, headlines, device=device)
    
    print(f"Price embedding shape: {z_price.shape}")
    print(f"News embedding shape: {z_news.shape}")
    
    # Compute loss
    loss = model.compute_contrastive_loss(z_price, z_news)
    print(f"Contrastive loss: {loss.item():.4f}")
    
    # Test fused embedding
    z_fused = model.get_fused_embedding(prices, headlines, device=device, fusion_method="concat")
    print(f"Fused embedding shape: {z_fused.shape}")

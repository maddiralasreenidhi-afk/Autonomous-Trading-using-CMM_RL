"""
News Encoder using FinBERT for sentiment analysis
Encodes news headlines into latent representations
"""
import torch
import torch.nn as nn
from typing import Optional, List
from transformers import AutoTokenizer, AutoModel
from loguru import logger


class NewsEncoder(nn.Module):
    """
    News encoder using pretrained FinBERT
    
    Input: List of text headlines
    Output: (batch, latent_dim)
    """
    
    def __init__(
        self,
        latent_dim: int = 32,
        bert_model: str = "ProsusAI/finbert",
        max_length: int = 128,
        freeze_bert: bool = True,
        dropout: float = 0.1
    ):
        super().__init__()
        
        self.latent_dim = latent_dim
        self.max_length = max_length
        
        # Load FinBERT tokenizer and model
        logger.info(f"Loading FinBERT model: {bert_model}")
        self.tokenizer = AutoTokenizer.from_pretrained(bert_model)
        self.bert = AutoModel.from_pretrained(bert_model)
        
        # Optionally freeze BERT parameters
        if freeze_bert:
            for param in self.bert.parameters():
                param.requires_grad = False
            logger.info("FinBERT parameters frozen")
        
        # Get BERT hidden size
        bert_hidden_size = self.bert.config.hidden_size
        
        # Projection head
        self.projection = nn.Sequential(
            nn.Linear(bert_hidden_size, bert_hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(bert_hidden_size // 2, latent_dim)
        )
        
        # Normalization
        self.norm = nn.LayerNorm(latent_dim)
    
    def forward(
        self,
        headlines: List[str],
        device: Optional[torch.device] = None
    ) -> torch.Tensor:
        """
        Encode news headlines
        
        Args:
            headlines: List of news headline strings
            device: Device to use
        
        Returns:
            z: (batch, latent_dim) - encoded representation
        """
        if device is None:
            device = next(self.parameters()).device
        
        # Tokenize
        encoding = self.tokenizer(
            headlines,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )
        
        # Move to device
        input_ids = encoding["input_ids"].to(device)
        attention_mask = encoding["attention_mask"].to(device)
        
        # Get BERT embeddings
        with torch.set_grad_enabled(not self.bert.training and any(p.requires_grad for p in self.bert.parameters())):
            outputs = self.bert(
                input_ids=input_ids,
                attention_mask=attention_mask
            )
        
        # Use [CLS] token embedding
        cls_embedding = outputs.last_hidden_state[:, 0, :]  # (batch, hidden_size)
        
        # Project to latent space
        z = self.projection(cls_embedding)
        z = self.norm(z)
        
        return z
    
    def encode_batch(
        self,
        headlines_batch: List[List[str]],
        device: Optional[torch.device] = None
    ) -> torch.Tensor:
        """
        Encode multiple sets of headlines (e.g., multiple news articles per sample)
        
        Args:
            headlines_batch: List of lists of headlines
            device: Device to use
        
        Returns:
            z: (batch, latent_dim) - mean encoding per sample
        """
        embeddings = []
        
        for headlines in headlines_batch:
            if len(headlines) == 0:
                # No news available - use zero embedding
                if device is None:
                    device = next(self.parameters()).device
                embeddings.append(torch.zeros(1, self.latent_dim, device=device))
            else:
                # Encode all headlines and take mean
                z = self(headlines, device=device)
                z_mean = z.mean(dim=0, keepdim=True)
                embeddings.append(z_mean)
        
        return torch.cat(embeddings, dim=0)


class NewsAggregator(nn.Module):
    """
    Aggregate multiple news embeddings with attention
    """
    
    def __init__(self, latent_dim: int = 32):
        super().__init__()
        
        self.attention = nn.Sequential(
            nn.Linear(latent_dim, latent_dim),
            nn.Tanh(),
            nn.Linear(latent_dim, 1)
        )
    
    def forward(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        Aggregate embeddings with attention
        
        Args:
            embeddings: (batch, num_articles, latent_dim)
        
        Returns:
            aggregated: (batch, latent_dim)
        """
        # Compute attention weights
        attn_weights = self.attention(embeddings)  # (batch, num_articles, 1)
        attn_weights = torch.softmax(attn_weights, dim=1)
        
        # Weighted sum
        aggregated = (embeddings * attn_weights).sum(dim=1)
        
        return aggregated


if __name__ == "__main__":
    # Test the news encoder
    try:
        headlines = [
            "Company reports strong quarterly earnings beating expectations",
            "Stock market faces headwinds amid economic uncertainty",
            "New product launch drives investor optimism",
            "Regulatory approval boosts pharmaceutical stocks"
        ]
        
        # Create encoder
        encoder = NewsEncoder(
            latent_dim=32,
            freeze_bert=True
        )
        
        # Encode
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        encoder = encoder.to(device)
        
        z = encoder(headlines, device=device)
        
        print(f"Headlines: {len(headlines)}")
        print(f"Output shape: {z.shape}")
        print(f"Output mean: {z.mean().item():.4f}, std: {z.std().item():.4f}")
        
        # Test batch encoding
        headlines_batch = [
            ["Positive earnings report", "Stock surges"],
            ["Market volatility increases"],
            []  # No news
        ]
        
        z_batch = encoder.encode_batch(headlines_batch, device=device)
        print(f"\nBatch output shape: {z_batch.shape}")
        
    except Exception as e:
        logger.error(f"Error testing news encoder: {e}")
        logger.info("Note: FinBERT model requires internet connection to download on first run")

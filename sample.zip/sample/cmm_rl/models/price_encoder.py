"""
Price Encoder using Temporal CNN
Encodes OHLCV price sequences into latent representations
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class PriceEncoder(nn.Module):
    """
    Temporal Convolutional Network for price encoding
    
    Input: (batch, seq_len, features)  # features = OHLCV (5)
    Output: (batch, latent_dim)
    """
    
    def __init__(
        self,
        input_features: int = 5,  # OHLCV
        hidden_channels: int = 64,
        latent_dim: int = 32,
        kernel_size: int = 3,
        num_layers: int = 4,
        dropout: float = 0.1
    ):
        super().__init__()
        
        self.input_features = input_features
        self.latent_dim = latent_dim
        
        # Input projection
        self.input_proj = nn.Conv1d(
            input_features,
            hidden_channels,
            kernel_size=1
        )
        
        # Temporal convolution layers with residual connections
        self.conv_layers = nn.ModuleList()
        for i in range(num_layers):
            dilation = 2 ** i
            self.conv_layers.append(
                TemporalBlock(
                    hidden_channels,
                    hidden_channels,
                    kernel_size,
                    dilation=dilation,
                    dropout=dropout
                )
            )
        
        # Global pooling and output projection
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, latent_dim)
        )
        
        # Normalization
        self.norm = nn.LayerNorm(latent_dim)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass
        
        Args:
            x: (batch, seq_len, features) - normalized OHLCV data
        
        Returns:
            z: (batch, latent_dim) - encoded representation
        """
        # Transpose for Conv1d: (batch, features, seq_len)
        x = x.transpose(1, 2)
        
        # Input projection
        x = self.input_proj(x)
        
        # Temporal convolutions
        for conv_layer in self.conv_layers:
            x = conv_layer(x)
        
        # Global pooling
        x = self.global_pool(x).squeeze(-1)
        
        # Final projection
        z = self.fc(x)
        z = self.norm(z)
        
        return z


class TemporalBlock(nn.Module):
    """
    Temporal convolution block with residual connection
    """
    
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        dilation: int = 1,
        dropout: float = 0.1
    ):
        super().__init__()
        
        padding = (kernel_size - 1) * dilation // 2
        
        self.conv1 = nn.Conv1d(
            in_channels,
            out_channels,
            kernel_size,
            padding=padding,
            dilation=dilation
        )
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.dropout1 = nn.Dropout(dropout)
        
        self.conv2 = nn.Conv1d(
            out_channels,
            out_channels,
            kernel_size,
            padding=padding,
            dilation=dilation
        )
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.dropout2 = nn.Dropout(dropout)
        
        # Residual connection
        self.residual = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass with residual connection"""
        residual = self.residual(x)
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)
        out = self.dropout1(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.dropout2(out)
        
        return F.relu(out + residual)


def normalize_ohlcv(
    prices: torch.Tensor,
    eps: float = 1e-8
) -> torch.Tensor:
    """
    Normalize OHLCV data
    
    Args:
        prices: (batch, seq_len, 5) - raw OHLCV data
    
    Returns:
        normalized: (batch, seq_len, 5) - normalized data
    """
    # Use log returns for O, H, L, C
    ohlc = prices[..., :4]
    volume = prices[..., 4:5]
    
    # Log returns (relative to first close)
    first_close = ohlc[:, 0:1, 3:4]  # (batch, 1, 1)
    ohlc_norm = torch.log((ohlc + eps) / (first_close + eps))
    
    # Normalize volume
    volume_mean = volume.mean(dim=1, keepdim=True)
    volume_std = volume.std(dim=1, keepdim=True) + eps
    volume_norm = (volume - volume_mean) / volume_std
    
    return torch.cat([ohlc_norm, volume_norm], dim=-1)


if __name__ == "__main__":
    # Test the price encoder
    batch_size = 8
    seq_len = 60
    features = 5
    
    # Create random price data
    prices = torch.randn(batch_size, seq_len, features) * 10 + 100
    
    # Normalize
    prices_norm = normalize_ohlcv(prices)
    
    # Create encoder
    encoder = PriceEncoder(
        input_features=features,
        hidden_channels=64,
        latent_dim=32
    )
    
    # Encode
    z = encoder(prices_norm)
    
    print(f"Input shape: {prices.shape}")
    print(f"Normalized shape: {prices_norm.shape}")
    print(f"Output shape: {z.shape}")
    print(f"Output mean: {z.mean().item():.4f}, std: {z.std().item():.4f}")

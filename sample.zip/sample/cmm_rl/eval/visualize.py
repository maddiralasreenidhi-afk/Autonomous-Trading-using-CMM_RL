"""
Visualization tools for trading performance
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Optional, List
from pathlib import Path


sns.set_style("whitegrid")


def plot_performance(
    portfolio_values: np.ndarray,
    benchmark_values: Optional[np.ndarray] = None,
    timestamps: Optional[List] = None,
    title: str = "Portfolio Performance",
    save_path: Optional[str] = None
):
    """
    Plot portfolio performance over time
    
    Args:
        portfolio_values: Array of portfolio values
        benchmark_values: Optional benchmark values for comparison
        timestamps: Optional timestamps for x-axis
        title: Plot title
        save_path: Path to save figure
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    x = timestamps if timestamps is not None else np.arange(len(portfolio_values))
    
    # Plot portfolio
    ax.plot(x, portfolio_values, label='Strategy', linewidth=2, color='blue')
    
    # Plot benchmark if provided
    if benchmark_values is not None:
        ax.plot(x, benchmark_values, label='Benchmark', linewidth=2, 
                color='red', alpha=0.7, linestyle='--')
    
    ax.set_xlabel('Time')
    ax.set_ylabel('Portfolio Value ($)')
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.show()


def plot_drawdown(
    portfolio_values: np.ndarray,
    timestamps: Optional[List] = None,
    title: str = "Drawdown",
    save_path: Optional[str] = None
):
    """
    Plot drawdown over time
    
    Args:
        portfolio_values: Array of portfolio values
        timestamps: Optional timestamps for x-axis
        title: Plot title
        save_path: Path to save figure
    """
    # Calculate drawdown
    cumulative_max = np.maximum.accumulate(portfolio_values)
    drawdowns = (portfolio_values - cumulative_max) / cumulative_max
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    x = timestamps if timestamps is not None else np.arange(len(drawdowns))
    
    # Plot drawdown
    ax.fill_between(x, drawdowns * 100, 0, color='red', alpha=0.3)
    ax.plot(x, drawdowns * 100, color='red', linewidth=2)
    
    ax.set_xlabel('Time')
    ax.set_ylabel('Drawdown (%)')
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
    
    # Highlight maximum drawdown
    max_dd_idx = np.argmin(drawdowns)
    ax.scatter(x[max_dd_idx], drawdowns[max_dd_idx] * 100, 
              color='darkred', s=100, zorder=5, label=f'Max DD: {drawdowns[max_dd_idx]*100:.2f}%')
    ax.legend()
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.show()


def plot_returns_distribution(
    portfolio_values: np.ndarray,
    title: str = "Returns Distribution",
    save_path: Optional[str] = None
):
    """
    Plot distribution of returns
    
    Args:
        portfolio_values: Array of portfolio values
        title: Plot title
        save_path: Path to save figure
    """
    # Calculate returns
    returns = np.diff(portfolio_values) / portfolio_values[:-1]
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Histogram
    axes[0].hist(returns * 100, bins=50, color='blue', alpha=0.7, edgecolor='black')
    axes[0].axvline(x=0, color='red', linestyle='--', linewidth=2)
    axes[0].set_xlabel('Returns (%)')
    axes[0].set_ylabel('Frequency')
    axes[0].set_title('Returns Histogram')
    axes[0].grid(True, alpha=0.3)
    
    # Q-Q plot
    from scipy import stats
    stats.probplot(returns, dist="norm", plot=axes[1])
    axes[1].set_title('Q-Q Plot')
    axes[1].grid(True, alpha=0.3)
    
    fig.suptitle(title, fontsize=14, y=1.02)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.show()


def plot_portfolio_composition(
    weights_history: np.ndarray,
    asset_names: List[str],
    timestamps: Optional[List] = None,
    title: str = "Portfolio Composition",
    save_path: Optional[str] = None
):
    """
    Plot portfolio weights over time (stacked area chart)
    
    Args:
        weights_history: (T, n_assets) array of portfolio weights
        asset_names: List of asset names
        timestamps: Optional timestamps for x-axis
        title: Plot title
        save_path: Path to save figure
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    x = timestamps if timestamps is not None else np.arange(len(weights_history))
    
    # Stacked area chart
    ax.stackplot(x, weights_history.T, labels=asset_names, alpha=0.7)
    
    ax.set_xlabel('Time')
    ax.set_ylabel('Weight')
    ax.set_title(title)
    ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
    ax.set_ylim([0, 1])
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.show()


def create_performance_report(
    portfolio_values: np.ndarray,
    metrics: dict,
    save_dir: str = "./outputs"
):
    """
    Create comprehensive performance report with multiple plots
    
    Args:
        portfolio_values: Array of portfolio values
        metrics: Dictionary of performance metrics
        save_dir: Directory to save plots
    """
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    
    # Plot performance
    plot_performance(
        portfolio_values,
        title=f"Portfolio Performance (Sharpe: {metrics.get('sharpe_ratio', 0):.2f})",
        save_path=str(save_dir / "performance.png")
    )
    
    # Plot drawdown
    plot_drawdown(
        portfolio_values,
        title=f"Drawdown (Max: {metrics.get('max_drawdown', 0)*100:.2f}%)",
        save_path=str(save_dir / "drawdown.png")
    )
    
    # Plot returns distribution
    plot_returns_distribution(
        portfolio_values,
        title=f"Returns Distribution (Win Rate: {metrics.get('win_rate', 0)*100:.2f}%)",
        save_path=str(save_dir / "returns_dist.png")
    )
    
    print(f"Performance report saved to {save_dir}")


if __name__ == "__main__":
    # Test visualization
    np.random.seed(42)
    
    # Generate sample data
    n_days = 252
    returns = np.random.randn(n_days) * 0.02 + 0.001
    portfolio_values = 100000 * (1 + returns).cumprod()
    portfolio_values = np.insert(portfolio_values, 0, 100000)
    
    # Test plots
    plot_performance(portfolio_values)
    plot_drawdown(portfolio_values)
    plot_returns_distribution(portfolio_values)

"""
Performance metrics for trading strategies
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from loguru import logger


def calculate_returns(portfolio_values: np.ndarray) -> np.ndarray:
    """Calculate returns from portfolio values"""
    returns = np.diff(portfolio_values) / portfolio_values[:-1]
    return returns


def calculate_sharpe_ratio(
    portfolio_values: np.ndarray,
    risk_free_rate: float = 0.05,
    periods_per_year: int = 252
) -> float:
    """
    Calculate annualized Sharpe ratio
    
    Args:
        portfolio_values: Array of portfolio values over time
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of trading periods per year
    
    Returns:
        sharpe_ratio: Annualized Sharpe ratio
    """
    returns = calculate_returns(portfolio_values)
    
    if len(returns) == 0 or np.std(returns) == 0:
        return 0.0
    
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    # Annualize
    annual_return = mean_return * periods_per_year
    annual_std = std_return * np.sqrt(periods_per_year)
    
    sharpe = (annual_return - risk_free_rate) / annual_std
    
    return sharpe


def calculate_sortino_ratio(
    portfolio_values: np.ndarray,
    risk_free_rate: float = 0.05,
    periods_per_year: int = 252
) -> float:
    """
    Calculate annualized Sortino ratio (uses downside deviation)
    
    Args:
        portfolio_values: Array of portfolio values over time
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of trading periods per year
    
    Returns:
        sortino_ratio: Annualized Sortino ratio
    """
    returns = calculate_returns(portfolio_values)
    
    if len(returns) == 0:
        return 0.0
    
    mean_return = np.mean(returns)
    
    # Calculate downside deviation
    downside_returns = returns[returns < 0]
    if len(downside_returns) == 0:
        return float('inf')
    
    downside_std = np.std(downside_returns)
    
    if downside_std == 0:
        return 0.0
    
    # Annualize
    annual_return = mean_return * periods_per_year
    annual_downside_std = downside_std * np.sqrt(periods_per_year)
    
    sortino = (annual_return - risk_free_rate) / annual_downside_std
    
    return sortino


def calculate_max_drawdown(portfolio_values: np.ndarray) -> Tuple[float, int, int]:
    """
    Calculate maximum drawdown
    
    Args:
        portfolio_values: Array of portfolio values over time
    
    Returns:
        max_dd: Maximum drawdown as a fraction
        start_idx: Start index of max drawdown period
        end_idx: End index of max drawdown period
    """
    if len(portfolio_values) == 0:
        return 0.0, 0, 0
    
    cumulative_max = np.maximum.accumulate(portfolio_values)
    drawdowns = (portfolio_values - cumulative_max) / cumulative_max
    
    max_dd = np.min(drawdowns)
    end_idx = np.argmin(drawdowns)
    
    # Find start of drawdown period
    start_idx = 0
    for i in range(end_idx, -1, -1):
        if portfolio_values[i] == cumulative_max[i]:
            start_idx = i
            break
    
    return abs(max_dd), start_idx, end_idx


def calculate_calmar_ratio(
    portfolio_values: np.ndarray,
    periods_per_year: int = 252
) -> float:
    """
    Calculate Calmar ratio (return / max drawdown)
    
    Args:
        portfolio_values: Array of portfolio values over time
        periods_per_year: Number of trading periods per year
    
    Returns:
        calmar_ratio: Calmar ratio
    """
    if len(portfolio_values) < 2:
        return 0.0
    
    # Calculate annualized return
    total_return = (portfolio_values[-1] / portfolio_values[0]) - 1
    n_periods = len(portfolio_values) - 1
    years = n_periods / periods_per_year
    annual_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0
    
    # Calculate max drawdown
    max_dd, _, _ = calculate_max_drawdown(portfolio_values)
    
    if max_dd == 0:
        return float('inf') if annual_return > 0 else 0.0
    
    calmar = annual_return / max_dd
    
    return calmar


def calculate_win_rate(portfolio_values: np.ndarray) -> float:
    """
    Calculate win rate (fraction of positive return periods)
    
    Args:
        portfolio_values: Array of portfolio values over time
    
    Returns:
        win_rate: Fraction of winning periods
    """
    returns = calculate_returns(portfolio_values)
    
    if len(returns) == 0:
        return 0.0
    
    win_rate = np.sum(returns > 0) / len(returns)
    
    return win_rate


def calculate_volatility(
    portfolio_values: np.ndarray,
    periods_per_year: int = 252
) -> float:
    """Calculate annualized volatility"""
    returns = calculate_returns(portfolio_values)
    
    if len(returns) == 0:
        return 0.0
    
    volatility = np.std(returns) * np.sqrt(periods_per_year)
    
    return volatility


def evaluate_strategy(
    portfolio_values: np.ndarray,
    initial_capital: float,
    risk_free_rate: float = 0.05,
    periods_per_year: int = 252
) -> Dict[str, float]:
    """
    Comprehensive strategy evaluation
    
    Args:
        portfolio_values: Array of portfolio values over time
        initial_capital: Initial portfolio value
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of trading periods per year
    
    Returns:
        metrics: Dictionary of performance metrics
    """
    if len(portfolio_values) == 0:
        logger.warning("Empty portfolio values array")
        return {}
    
    # Calculate returns
    total_return = (portfolio_values[-1] / initial_capital) - 1
    
    # Annualized return
    n_periods = len(portfolio_values) - 1
    years = n_periods / periods_per_year
    annual_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0
    
    # Calculate metrics
    sharpe = calculate_sharpe_ratio(portfolio_values, risk_free_rate, periods_per_year)
    sortino = calculate_sortino_ratio(portfolio_values, risk_free_rate, periods_per_year)
    max_dd, dd_start, dd_end = calculate_max_drawdown(portfolio_values)
    calmar = calculate_calmar_ratio(portfolio_values, periods_per_year)
    win_rate = calculate_win_rate(portfolio_values)
    volatility = calculate_volatility(portfolio_values, periods_per_year)
    
    metrics = {
        'total_return': total_return,
        'annual_return': annual_return,
        'sharpe_ratio': sharpe,
        'sortino_ratio': sortino,
        'max_drawdown': max_dd,
        'max_drawdown_start': dd_start,
        'max_drawdown_end': dd_end,
        'calmar_ratio': calmar,
        'win_rate': win_rate,
        'volatility': volatility,
        'final_value': portfolio_values[-1],
        'total_periods': len(portfolio_values)
    }
    
    logger.info("Strategy Evaluation:")
    logger.info(f"  Total Return: {total_return*100:.2f}%")
    logger.info(f"  Annual Return: {annual_return*100:.2f}%")
    logger.info(f"  Sharpe Ratio: {sharpe:.2f}")
    logger.info(f"  Sortino Ratio: {sortino:.2f}")
    logger.info(f"  Max Drawdown: {max_dd*100:.2f}%")
    logger.info(f"  Calmar Ratio: {calmar:.2f}")
    logger.info(f"  Win Rate: {win_rate*100:.2f}%")
    logger.info(f"  Volatility: {volatility*100:.2f}%")
    
    return metrics


if __name__ == "__main__":
    # Test metrics
    np.random.seed(42)
    
    # Generate sample portfolio values
    n_days = 252
    returns = np.random.randn(n_days) * 0.02 + 0.001  # 2% daily vol, 0.1% drift
    portfolio_values = 100000 * (1 + returns).cumprod()
    portfolio_values = np.insert(portfolio_values, 0, 100000)
    
    # Evaluate
    metrics = evaluate_strategy(portfolio_values, 100000)
    
    print("\nMetrics:")
    for key, value in metrics.items():
        print(f"{key}: {value}")

"""
CMM-RL: Contrastive Multi-Modal Reinforcement Learning
"""
__version__ = "0.1.0"

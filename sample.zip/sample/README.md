# Contrastive Multi-Modal Reinforcement Learning (CMM-RL)

A production-ready pipeline for **market regime learning** and **autonomous trading** using stock price data and news sentiment. Combines **contrastive self-supervised learning** with **reinforcement learning** for dynamic portfolio allocation.

---

## 🔍 Key Features

* **Stock Data via Twelve Data API**

  * *Historical Prices* (Backtests, Contrastive Pretraining)
  * *Latest Market Data* (Portfolio Decisions)
  * *News Headlines* (Sentiment Embeddings via FinBERT)

* **Fully Automated Trading Agent**

  * Learns joint market regimes via contrastive encoders
  * Executes allocation via PPO-based policy
  * Supports US and international markets

* **Multi-Modal Encoder Architecture**

  * Price Encoder (Temporal CNN)
  * News Encoder (FinBERT + MLP)
  * NT-Xent Contrastive Loss
  * Joint latent state `z_t ∈ ℝ³²`

* **Reinforcement Learning Loop**

  * State: `[z_t, portfolio_state]`
  * Action: Portfolio weights per asset
  * Reward: Return minus risk regularizer
  * Agent: PPO (Stable-Baselines3)

* **Performance Metrics**
  Sharpe, Sortino, Max Drawdown, Total Return, Hit Rate

---

## 🧠 Pipeline Overview

```
      Twelve Data API                     Model + Training                     Runtime Agent
┌────────────────────┐              ┌──────────────────────────┐          ┌──────────────────────┐
│ • Historical Prices │────────────►│  Contrastive Pretraining │          │  RL Inference        │
│ • News Headlines    │             │  (price ↔ news encoder)  │──────┐   │  + Latest Data       │
│ • Latest Ticks      │             └──────────────────────────┘      │   │  + Portfolio Mgmt    │
└────────────────────┘                                                │   └──────────────────────┘
                                                                      ▼
                                                       ┌─────────────────────────────┐
                                                       │  PPO + Portfolio Allocation │
                                                       └─────────────────────────────┘
```

---

## ⚙️ Quickstart (Windows PowerShell)

```powershell
# 1) Create VENV
python -m venv .venv
. .\.venv\Scripts\Activate.ps1

# 2) Install requirements
pip install -r requirements.txt

# 3) Set up your API key
cp .env.example .env
# Edit .env and add your TWELVE_DATA_API_KEY

# 4) Contrastive Pretraining
python -m cmm_rl.training.train_contrastive --config .\configs\contrastive.yaml

# 5) PPO Training on encoded z_t states
python -m cmm_rl.rl.train_rl --config .\configs\rl.yaml

# 6) Run inference
$env:TICKER="AAPL"
$env:USE_NEWS="true"

python .\scripts\live_infer.py
```

---

## 📁 Project Structure

```
cmm_rl/
├── data/          # Price + News fetch via Twelve Data API
├── models/        # Price encoder, News encoder, Fusion head
├── training/      # Self-supervised contrastive loop
├── rl/            # Gymnasium env + PPO agent
├── eval/          # Sharpe, MDD, ROI, plots
├── utils/         # Metrics, configs, logging
configs/           # YAML configs for each module
scripts/           # Live trading, backtest, report export
tests/             # Smoke tests
```

---

## 🔑 Twelve Data API Setup

This project uses **Twelve Data API** for stock market data.

### Get Your API Key

1. **Sign up** at [Twelve Data](https://twelvedata.com/)
2. **Get your free API key** (800 API calls per day on free tier)

### Configure Credentials

```powershell
# Copy environment template
cp .env.example .env

# Edit .env with your API key
notepad .env
```

Add to `.env`:
```
TWELVE_DATA_API_KEY=your_api_key_here
```

### Supported Symbols

- **US Stocks**: AAPL, GOOGL, MSFT, TSLA, etc.
- **Indian Stocks**: Use exchange suffix (e.g., RELIANCE for NSE stocks)
- **International**: Most global exchanges supported

---

## 📊 Architecture Details

### 1. Contrastive Pretraining Phase
- Fetch historical prices + news for multiple stocks
- Train encoders to maximize similarity between aligned price/news pairs
- Save pretrained encoder checkpoints

### 2. RL Training Phase
- Use frozen/fine-tuned encoders to produce state embeddings
- Train PPO agent on portfolio allocation task
- Optimize for risk-adjusted returns

### 3. Live Trading Phase
- Stream real-time prices and news
- Encode state with pretrained models
- Execute trades based on RL policy

---

## 🚀 Development

```powershell
# Run tests
pytest tests/

# Backtest strategy
python .\scripts\backtest.py --start 2023-01-01 --end 2024-01-01

# Generate performance report
python .\scripts\generate_report.py --results .\outputs\results.json
```

---

## 📈 Expected Performance

- **Sharpe Ratio**: > 1.5
- **Max Drawdown**: < 20%
- **Annual Return**: Target 15-25%
- **Win Rate**: > 55%

---

## ⚠️ Disclaimer

This is an experimental research project. Do not use in production with real money without thorough testing and risk management. Past performance does not guarantee future results.

---

## 📝 License

MIT License - See LICENSE file for details.

---

## 🤝 Contributing

Pull requests are welcome! Please ensure tests pass before submitting.


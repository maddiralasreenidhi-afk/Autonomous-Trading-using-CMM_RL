"""
Generate performance report from backtest results
"""
import json
import argparse
import numpy as np
from pathlib import Path
from loguru import logger

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from cmm_rl.eval import create_performance_report
from cmm_rl.utils import format_currency


def generate_report(results_file: str, output_dir: str = None):
    """
    Generate performance report from results file
    
    Args:
        results_file: Path to results JSON file
        output_dir: Directory to save report (default: same as results file)
    """
    results_file = Path(results_file)
    
    if not results_file.exists():
        raise FileNotFoundError(f"Results file not found: {results_file}")
    
    # Load results
    with open(results_file, 'r') as f:
        results = json.load(f)
    
    portfolio_values = np.array(results['portfolio_values'])
    metrics = results['metrics']
    config = results.get('config', {})
    
    # Determine output directory
    if output_dir is None:
        output_dir = results_file.parent
    else:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Generating report for {results_file}")
    
    # Print summary
    print("\n" + "=" * 60)
    print("BACKTEST PERFORMANCE REPORT")
    print("=" * 60)
    
    if config:
        print("\nConfiguration:")
        if 'ticker' in config:
            print(f"  Ticker: {config['ticker']}")
        elif 'tickers' in config:
            print(f"  Tickers: {', '.join(config.get('tickers', []))}")
        print(f"  Period: {config.get('start_date')} to {config.get('end_date')}")
        print(f"  Initial Capital: {format_currency(config.get('initial_capital', 0))}")
        print(f"  Use News: {config.get('use_news', False)}")
    
    print("\nPerformance Metrics:")
    print(f"  Total Return: {metrics['total_return']*100:.2f}%")
    print(f"  Annual Return: {metrics['annual_return']*100:.2f}%")
    print(f"  Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
    print(f"  Sortino Ratio: {metrics['sortino_ratio']:.2f}")
    print(f"  Max Drawdown: {metrics['max_drawdown']*100:.2f}%")
    print(f"  Calmar Ratio: {metrics['calmar_ratio']:.2f}")
    print(f"  Win Rate: {metrics['win_rate']*100:.2f}%")
    print(f"  Volatility: {metrics['volatility']*100:.2f}%")
    
    print(f"\n  Final Portfolio Value: {format_currency(metrics['final_value'])}")
    print(f"  Total Trading Periods: {metrics['total_periods']}")
    
    print("=" * 60 + "\n")
    
    # Create visualizations
    logger.info("Creating visualizations...")
    create_performance_report(
        portfolio_values,
        metrics,
        save_dir=str(output_dir)
    )
    
    # Save text report
    report_file = output_dir / "report.txt"
    with open(report_file, 'w') as f:
        f.write("BACKTEST PERFORMANCE REPORT\n")
        f.write("=" * 60 + "\n\n")
        
        if config:
            f.write("Configuration:\n")
            for key, value in config.items():
                f.write(f"  {key}: {value}\n")
            f.write("\n")
        
        f.write("Performance Metrics:\n")
        for key, value in metrics.items():
            if isinstance(value, float):
                f.write(f"  {key}: {value:.4f}\n")
            else:
                f.write(f"  {key}: {value}\n")
    
    logger.info(f"Report saved to {output_dir}")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Generate performance report')
    parser.add_argument('--results', type=str, required=True,
                       help='Path to results JSON file')
    parser.add_argument('--output', type=str, default=None,
                       help='Output directory (default: same as results file)')
    
    args = parser.parse_args()
    
    generate_report(args.results, args.output)


if __name__ == "__main__":
    main()

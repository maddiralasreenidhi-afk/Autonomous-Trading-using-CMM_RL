"""
Backtest trading strategy on historical data (single-stock mode)
"""
import os
import sys
import argparse
from dotenv import load_dotenv
import torch
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent.parent))

from cmm_rl.rl.environment import TradingEnv
from cmm_rl.models import PriceEncoder, NewsEncoder, ContrastiveModel
from cmm_rl.data import HistoricalDataFetcher, NewsFetcher
from cmm_rl.eval import evaluate_strategy, create_performance_report
from cmm_rl.utils import setup_logger
from stable_baselines3 import PPO


class RandomAgent:
    """Fallback agent that samples random actions when RL model is unavailable"""
    def __init__(self, action_space):
        self.action_space = action_space

    def predict(self, obs, deterministic=True):
        action = self.action_space.sample()
        return action, None


def backtest(
    rl_model_path: str,
    encoder_model_path: str,
    ticker: str,
    start_date: str,
    end_date: str,
    initial_capital: float = 100000,
    use_news: bool = True,
    output_dir: str = "./outputs/backtest"
):
    """
    Backtest trading strategy
    
    Args:
        rl_model_path: Path to trained RL model
        encoder_model_path: Path to trained encoder
    ticker: Single stock symbol to trade (e.g., 'TATASTEEL')
        start_date: Start date for backtest
        end_date: End date for backtest
        initial_capital: Initial capital
        use_news: Whether to use news data
        output_dir: Directory to save results
    """
    logger.info("Starting backtest...")
    logger.info(f"Period: {start_date} to {end_date}")
    logger.info(f"Ticker: {ticker}")
    
    # Setup
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load encoder
    logger.info("Loading encoder...")
    price_encoder = PriceEncoder(input_features=5, latent_dim=32, hidden_channels=64)
    news_encoder = NewsEncoder(latent_dim=32, freeze_bert=True)
    encoder = ContrastiveModel(price_encoder, news_encoder)
    
    if os.path.exists(encoder_model_path):
        checkpoint = torch.load(encoder_model_path, map_location=device)
        encoder.load_state_dict(checkpoint['model_state_dict'])
        logger.info(f"Encoder loaded from {encoder_model_path}")
    else:
        logger.warning("Encoder checkpoint not found, using untrained encoder")
    
    encoder.to(device)
    encoder.eval()
    
    # Fetch data
    logger.info("Fetching market data...")
    price_fetcher = HistoricalDataFetcher()
    news_fetcher = NewsFetcher()
    
    price_data = {ticker: price_fetcher.fetch(ticker, start_date, end_date)}
    news_data = {ticker: news_fetcher.fetch_headlines(ticker, start_date, end_date)}

    # Display fetched data previews
    try:
        df_prices = price_data[ticker]
        print("\n=== Historical OHLCV (preview) ===")
        print(f"Ticker: {ticker}")
        if not df_prices.empty:
            print(f"Rows: {len(df_prices)} | Range: {df_prices['timestamp'].min().date()} -> {df_prices['timestamp'].max().date()}")
            print(df_prices[['timestamp', 'open', 'high', 'low', 'close', 'volume']].head(5).to_string(index=False))
        else:
            print("No historical data returned.")

        df_news = news_data[ticker]
        print("\n=== News Headlines (preview) ===")
        print(f"Ticker: {ticker}")
        if not df_news.empty:
            print(f"Articles: {len(df_news)} | Range: {df_news['timestamp'].min().date()} -> {df_news['timestamp'].max().date()}")
            preview = df_news[['timestamp', 'headline', 'source']].head(5).copy()
            # Shorten long headlines for console readability
            preview['headline'] = preview['headline'].astype(str).str.slice(0, 90)
            print(preview.to_string(index=False))
        else:
            print("No news data returned.")
    except Exception as _e:
        logger.debug(f"Preview print skipped: {_e}")
    
    # Create environment
    logger.info("Creating backtest environment...")
    window_size = 60
    # Basic sanity check: ensure enough bars for the chosen window size
    if len(price_data[ticker]) < window_size + 1:
        msg = (
            f"Insufficient historical data for window_size={window_size}. "
            f"Need at least {window_size+1} rows, got {len(price_data[ticker])}. "
            f"Try expanding the date range."
        )
        logger.error(msg)
        print("\n✗ " + msg)
        return {}, np.array([])

    env = TradingEnv(
        price_data=price_data,
        news_data=news_data,
        encoder_model=encoder,
        initial_capital=initial_capital,
        window_size=window_size,
        transaction_cost=0.001,
        risk_penalty=0.1,
        use_news=use_news
    )
    
    # Load RL model (after env is available), fallback to RandomAgent if missing
    logger.info("Loading RL agent...")
    if os.path.exists(rl_model_path):
        rl_agent = PPO.load(rl_model_path, device=device)
        logger.info(f"RL agent loaded from {rl_model_path}")
    else:
        logger.warning(f"RL model not found at {rl_model_path}. Using RandomAgent fallback.")
        rl_agent = RandomAgent(env.action_space)
    
    # Run backtest
    logger.info("Running backtest...")
    state, info = env.reset()
    
    portfolio_values = [initial_capital]
    returns = []
    actions_history = []
    
    done = False
    step = 0
    
    while not done:
        # Get action from agent
        action, _ = rl_agent.predict(state, deterministic=True)
        actions_history.append(action)
        
        # Step environment
        state, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated
        
        # Track metrics
        portfolio_values.append(info['portfolio_value'])
        returns.append(reward)
        
        step += 1
        
        if step % 50 == 0:
            logger.info(f"Step {step}: Value={info['portfolio_value']:.2f}, Reward={reward:.4f}")
    
    logger.info(f"Backtest completed: {step} steps")
    
    # Evaluate performance
    logger.info("Evaluating performance...")
    portfolio_values = np.array(portfolio_values)
    metrics = evaluate_strategy(
        portfolio_values,
        initial_capital,
        risk_free_rate=0.05,
        periods_per_year=252
    )
    
    # Save results
    results = {
        'config': {
            'ticker': ticker,
            'start_date': start_date,
            'end_date': end_date,
            'initial_capital': initial_capital,
            'use_news': use_news
        },
        'metrics': metrics,
        'portfolio_values': portfolio_values.tolist()
    }
    
    import json
    
    # JSON helper to serialize numpy types
    def _json_default(o):
        import numpy as _np
        if isinstance(o, (_np.integer,)):
            return int(o)
        if isinstance(o, (_np.floating,)):
            return float(o)
        if isinstance(o, (_np.ndarray,)):
            return o.tolist()
        return str(o)
    results_file = output_dir / "results.json"
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2, default=_json_default)
    logger.info(f"Results saved to {results_file}")
    
    # Create performance report
    logger.info("Creating performance report...")
    create_performance_report(
        portfolio_values,
        metrics,
        save_dir=str(output_dir)
    )
    
    logger.info(f"Backtest complete! Results saved to {output_dir}")
    
    return metrics, portfolio_values


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Backtest trading strategy (single stock)')
    parser.add_argument('--rl-model', type=str, default='./checkpoints/rl/best_model/best_model.zip',
                       help='Path to RL model')
    parser.add_argument('--encoder-model', type=str, default='./checkpoints/contrastive/best_model.pth',
                       help='Path to encoder model')
    parser.add_argument('--ticker', type=str, default=None,
                       help='stock symbol to trade (overrides .env TICKER if provided)')
    parser.add_argument('--start', type=str, default='2023-01-01', help='Start date')
    parser.add_argument('--end', type=str, default='2024-01-01', help='End date')
    parser.add_argument('--capital', type=float, default=100000, help='Initial capital')
    parser.add_argument('--no-news', action='store_true', help='Disable news data')
    parser.add_argument('--output', type=str, default='./outputs/backtest', help='Output directory')
    
    args = parser.parse_args()
    
    # Load env and setup logger
    load_dotenv()
    setup_logger(f"{args.output}/backtest.log", level="INFO")
    
    # Resolve ticker from CLI or .env (default to TATASTEEL)
    env_ticker = os.getenv("TICKER", "TATASTEEL").strip().upper()
    ticker = (args.ticker or env_ticker).upper()
    
    logger.info(f"Using ticker: {ticker} (source: {'CLI' if args.ticker else '.env/default'})")
    
    # Run backtest
    backtest(
        rl_model_path=args.rl_model,
        encoder_model_path=args.encoder_model,
        ticker=ticker,
        start_date=args.start,
        end_date=args.end,
        initial_capital=args.capital,
        use_news=not args.no_news,
        output_dir=args.output
    )


if __name__ == "__main__":
    main()

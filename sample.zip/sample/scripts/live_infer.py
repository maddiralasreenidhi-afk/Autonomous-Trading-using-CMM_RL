"""
Live Trading Inference Script
Runs the trained RL agent in real-time with live market data
"""
import os
import sys
import time
import torch
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from dotenv import load_dotenv
from loguru import logger

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from cmm_rl.models import PriceEncoder, NewsEncoder, ContrastiveModel
from cmm_rl.models.price_encoder import normalize_ohlcv
from cmm_rl.data import HistoricalDataFetcher, LiveMarketFeed, NewsFetcher, MockLiveFeed
from cmm_rl.utils import setup_logger, format_currency
from stable_baselines3 import PPO


class LiveTradingAgent:
    """Real-time trading agent"""
    
    def __init__(
        self,
        rl_model_path: str,
        encoder_model_path: str,
        tickers: list,
        window_size: int = 60,
        use_news: bool = True,
        initial_capital: float = 100000
    ):
        self.tickers = tickers
        self.window_size = window_size
        self.use_news = use_news
        self.initial_capital = initial_capital
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"Using device: {self.device}")
        
        # Load models
        self.encoder = self._load_encoder(encoder_model_path)
        self.rl_agent = PPO.load(rl_model_path, device=self.device)
        logger.info("Models loaded successfully")
        
        # Data fetchers
        self.historical_fetcher = HistoricalDataFetcher()
        self.news_fetcher = NewsFetcher()
        
        # Price buffers (store recent price history)
        self.price_buffers = {ticker: [] for ticker in tickers}
        
        # Portfolio state
        self.portfolio_value = initial_capital
        self.cash = initial_capital
        self.holdings = {ticker: 0 for ticker in tickers}
        self.portfolio_weights = np.zeros(len(tickers) + 1)
        self.portfolio_weights[-1] = 1.0  # Start with 100% cash
        
    def _load_encoder(self, checkpoint_path: str) -> ContrastiveModel:
        """Load pretrained encoder"""
        logger.info(f"Loading encoder from {checkpoint_path}")
        
        price_encoder = PriceEncoder(
            input_features=5,
            latent_dim=32,
            hidden_channels=64
        )
        
        news_encoder = NewsEncoder(
            latent_dim=32,
            freeze_bert=True
        )
        
        model = ContrastiveModel(price_encoder, news_encoder)
        
        if os.path.exists(checkpoint_path):
            checkpoint = torch.load(checkpoint_path, map_location=self.device)
            model.load_state_dict(checkpoint['model_state_dict'])
            logger.info("Encoder loaded")
        else:
            logger.warning(f"Checkpoint not found: {checkpoint_path}")
            logger.warning("Using untrained encoder")
        
        model.to(self.device)
        model.eval()
        
        return model
    
    def initialize_price_buffers(self):
        """Initialize price buffers with recent historical data"""
        logger.info("Initializing price buffers...")
        
        end_date = datetime.now().strftime("%Y-%m-%d")
        start_date = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
        
        for ticker in self.tickers:
            df = self.historical_fetcher.fetch(ticker, start_date, end_date)
            
            if len(df) >= self.window_size:
                # Take last window_size points
                recent_data = df.tail(self.window_size)
                self.price_buffers[ticker] = recent_data[
                    ['timestamp', 'open', 'high', 'low', 'close', 'volume']
                ].to_dict('records')
                logger.info(f"{ticker}: Initialized with {len(self.price_buffers[ticker])} data points")
            else:
                logger.warning(f"{ticker}: Insufficient historical data")
    
    def update_price_buffer(self, ticker: str, price_data: dict):
        """Update price buffer with new data"""
        self.price_buffers[ticker].append(price_data)
        
        # Keep only last window_size points
        if len(self.price_buffers[ticker]) > self.window_size:
            self.price_buffers[ticker].pop(0)
    
    def get_state(self) -> np.ndarray:
        """Get current state representation"""
        # Prepare price windows
        price_windows = []
        for ticker in self.tickers:
            buffer = self.price_buffers[ticker]
            if len(buffer) < self.window_size:
                logger.warning(f"{ticker}: Insufficient data in buffer")
                return None
            
            # Extract OHLCV
            ohlcv = np.array([
                [p['open'], p['high'], p['low'], p['close'], p['volume']]
                for p in buffer
            ])
            price_windows.append(ohlcv)
        
        # Encode state
        with torch.no_grad():
            prices_batch = torch.FloatTensor(np.array(price_windows)).to(self.device)
            prices_batch = normalize_ohlcv(prices_batch)
            
            if self.use_news:
                # Get recent news
                headlines = []
                for ticker in self.tickers:
                    news_df = self.news_fetcher.fetch_latest(ticker, limit=3)
                    if len(news_df) > 0:
                        headlines.append(news_df[0]['headline'])
                    else:
                        headlines.append(f"No news for {ticker}")
                
                latent = self.encoder.get_fused_embedding(
                    prices_batch, headlines, device=self.device, fusion_method="mean"
                )
            else:
                latent = self.encoder.price_encoder(prices_batch)
            
            latent = latent.mean(dim=0).cpu().numpy()
        
        # Construct state
        normalized_value = np.log(self.portfolio_value / self.initial_capital + 1e-8)
        state = np.concatenate([
            latent,
            self.portfolio_weights,
            [normalized_value]
        ]).astype(np.float32)
        
        return state
    
    def execute_action(self, action: np.ndarray, current_prices: dict):
        """Execute portfolio rebalancing"""
        # Convert action to weights
        weights = np.exp(action) / np.sum(np.exp(action))
        weights = np.clip(weights, 0, 1)
        weights = weights / weights.sum()
        
        # Calculate new holdings
        prices = np.array([current_prices[ticker] for ticker in self.tickers])
        target_values = weights[:-1] * self.portfolio_value
        new_holdings = target_values / prices
        
        # Update portfolio
        for i, ticker in enumerate(self.tickers):
            self.holdings[ticker] = new_holdings[i]
        
        self.cash = weights[-1] * self.portfolio_value
        self.portfolio_weights = weights
        
        logger.info(f"Portfolio rebalanced: {dict(zip(self.tickers + ['CASH'], weights))}")
    
    def update_portfolio_value(self, current_prices: dict):
        """Update portfolio value based on current prices"""
        holdings_value = sum(
            self.holdings[ticker] * current_prices[ticker]
            for ticker in self.tickers
        )
        
        self.portfolio_value = holdings_value + self.cash
        
        logger.info(f"Portfolio value: {format_currency(self.portfolio_value)}")
    
    def run(self, update_interval: int = 60, use_mock_feed: bool = False):
        """Run live trading loop"""
        logger.info("Starting live trading agent...")
        
        # Initialize price buffers
        self.initialize_price_buffers()
        
        # Connect to live feed
        if use_mock_feed:
            logger.info("Using mock live feed for testing")
            feed_class = MockLiveFeed
        else:
            feed_class = LiveMarketFeed
        
        def on_price_update(data):
            """Callback for price updates"""
            ticker = data.get('ticker')
            if ticker not in self.tickers:
                return
            
            # Update price buffer
            price_data = {
                'timestamp': datetime.fromtimestamp(data['timestamp']),
                'open': data['price'],
                'high': data['price'],
                'low': data['price'],
                'close': data['price'],
                'volume': data.get('volume', 0)
            }
            self.update_price_buffer(ticker, price_data)
        
        with feed_class(callback=on_price_update) as feed:
            # Subscribe to tickers
            for ticker in self.tickers:
                feed.subscribe(ticker)
            
            logger.info(f"Subscribed to {len(self.tickers)} tickers")
            logger.info(f"Update interval: {update_interval}s")
            
            try:
                while True:
                    # Get current state
                    state = self.get_state()
                    
                    if state is not None:
                        # Get action from RL agent
                        action, _ = self.rl_agent.predict(state, deterministic=True)
                        
                        # Get current prices
                        current_prices = {
                            ticker: self.price_buffers[ticker][-1]['close']
                            for ticker in self.tickers
                        }
                        
                        # Execute action
                        self.execute_action(action, current_prices)
                        
                        # Update portfolio value
                        self.update_portfolio_value(current_prices)
                        
                        # Print portfolio status
                        logger.info(f"Holdings: {self.holdings}")
                        logger.info(f"Cash: {format_currency(self.cash)}")
                        logger.info(f"Total Value: {format_currency(self.portfolio_value)}")
                        logger.info(f"Return: {(self.portfolio_value / self.initial_capital - 1) * 100:.2f}%")
                    
                    # Wait for next update
                    time.sleep(update_interval)
            
            except KeyboardInterrupt:
                logger.info("Stopping live trading agent...")


def main():
    """Main function"""
    # Load environment variables
    load_dotenv()
    
    # Setup logger
    setup_logger("./logs/live_trading.log", level="INFO")
    
    # Get configuration from environment (single stock)
    ticker = os.getenv("TICKER", "TATASTEEL").strip().upper()
    use_news = os.getenv("USE_NEWS", "true").lower() == "true"
    
    # Single-stock mode
    tickers = [ticker]
    
    # Model paths
    rl_model_path = "./checkpoints/rl/best_model/best_model.zip"
    encoder_model_path = "./checkpoints/contrastive/best_model.pth"
    
    logger.info(f"Trading ticker: {ticker}")
    logger.info(f"Use news: {use_news}")
    
    # Create trading agent
    agent = LiveTradingAgent(
        rl_model_path=rl_model_path,
        encoder_model_path=encoder_model_path,
        tickers=tickers,
        window_size=60,
        use_news=use_news,
        initial_capital=100000
    )
    
    # Run agent (use mock feed if API not available)
    use_mock = not os.getenv("INDIANAPI_NEWS_KEY")
    if use_mock:
        logger.warning("API keys not found, using mock feed for testing")
    
    agent.run(update_interval=60, use_mock_feed=use_mock)


if __name__ == "__main__":
    main()

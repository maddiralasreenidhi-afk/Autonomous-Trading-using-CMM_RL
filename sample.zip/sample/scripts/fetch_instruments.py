"""
Fetch AngelOne OpenAPI Scrip Master and build a local token map for NSE equities.
"""
import json
from pathlib import Path
import requests
from loguru import logger

SCRIP_URL = "https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
OUT_DIR = Path("data") / "instruments"
SCRIP_PATH = OUT_DIR / "OpenAPIScripMaster.json"
TOKEN_MAP_PATH = OUT_DIR / "token_map.json"


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    logger.info("Downloading OpenAPI Scrip Master from AngelOne ...")
    r = requests.get(SCRIP_URL, timeout=60)
    r.raise_for_status()
    data = r.json()
    SCRIP_PATH.write_text(json.dumps(data))
    logger.info(f"Saved scrip master to {SCRIP_PATH}")

    # Build token map for quick lookups: key = tradingsymbol, value = token
    token_map = {}
    for item in data:
        exch = str(item.get('exch_seg'))
        symbol = item.get('symbol')
        token = item.get('token')
        if exch == 'NSE' and symbol and token:
            token_map[symbol.upper()] = str(token)

    TOKEN_MAP_PATH.write_text(json.dumps(token_map, indent=2))
    logger.info(f"Saved NSE token map to {TOKEN_MAP_PATH} (entries: {len(token_map)})")


if __name__ == "__main__":
    main()

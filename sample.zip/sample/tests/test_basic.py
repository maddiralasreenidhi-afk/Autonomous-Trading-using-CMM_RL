"""
Basic smoke tests for CMM-RL project
"""
import pytest
import numpy as np
import torch
import pandas as pd
from datetime import datetime, timedelta


def test_imports():
    """Test that all modules can be imported"""
    try:
        from cmm_rl.data import HistoricalDataFetcher, NewsFetcher, LiveMarketFeed
        from cmm_rl.models import PriceEncoder, NewsEncoder, ContrastiveModel
        from cmm_rl.training import ContrastiveTrainer, ContrastiveDataset
        from cmm_rl.rl import TradingEnv, RLTrainer
        from cmm_rl.eval import evaluate_strategy, calculate_sharpe_ratio
        from cmm_rl.utils import load_config, setup_logger, set_seed
        assert True
    except ImportError as e:
        pytest.fail(f"Import failed: {e}")


def test_price_encoder():
    """Test price encoder"""
    from cmm_rl.models import PriceEncoder
    from cmm_rl.models.price_encoder import normalize_ohlcv
    
    encoder = PriceEncoder(input_features=5, latent_dim=32)
    
    # Create sample data
    batch_size = 4
    seq_len = 60
    prices = torch.randn(batch_size, seq_len, 5) * 10 + 100
    prices_norm = normalize_ohlcv(prices)
    
    # Forward pass
    z = encoder(prices_norm)
    
    assert z.shape == (batch_size, 32)
    assert not torch.isnan(z).any()


def test_contrastive_dataset():
    """Test dataset creation"""
    from cmm_rl.training import ContrastiveDataset
    
    # Create mock data
    n_days = 100
    timestamps = pd.date_range(start='2023-01-01', periods=n_days, freq='D')
    
    price_data = {
        'TEST': pd.DataFrame({
            'timestamp': timestamps,
            'open': np.random.randn(n_days) * 2 + 100,
            'high': np.random.randn(n_days) * 2 + 102,
            'low': np.random.randn(n_days) * 2 + 98,
            'close': np.random.randn(n_days) * 2 + 100,
            'volume': np.random.randint(1000, 10000, n_days)
        })
    }
    
    news_data = {
        'TEST': pd.DataFrame({
            'timestamp': timestamps[:10],
            'headline': [f'Test headline {i}' for i in range(10)]
        })
    }
    
    dataset = ContrastiveDataset(price_data, news_data, window_size=20, stride=5)
    
    assert len(dataset) > 0
    
    prices, headlines, ticker = dataset[0]
    assert prices.shape[0] == 20
    assert prices.shape[1] == 5
    assert isinstance(headlines, list)
    assert ticker == 'TEST'


def test_metrics():
    """Test performance metrics"""
    from cmm_rl.eval import calculate_sharpe_ratio, calculate_max_drawdown
    
    # Generate sample portfolio values
    n_days = 252
    returns = np.random.randn(n_days) * 0.01 + 0.0002
    portfolio_values = 100000 * (1 + returns).cumprod()
    portfolio_values = np.insert(portfolio_values, 0, 100000)
    
    sharpe = calculate_sharpe_ratio(portfolio_values)
    max_dd, start, end = calculate_max_drawdown(portfolio_values)
    
    assert isinstance(sharpe, float)
    assert isinstance(max_dd, float)
    assert 0 <= max_dd <= 1
    assert start <= end


def test_trading_env():
    """Test trading environment"""
    from cmm_rl.rl import TradingEnv
    
    # Create mock data
    n_days = 200
    timestamps = pd.date_range(start='2023-01-01', periods=n_days, freq='D')
    
    price_data = {
        'ASSET1': pd.DataFrame({
            'timestamp': timestamps,
            'open': np.random.randn(n_days) * 2 + 100,
            'high': np.random.randn(n_days) * 2 + 102,
            'low': np.random.randn(n_days) * 2 + 98,
            'close': np.random.randn(n_days) * 2 + 100,
            'volume': np.random.randint(1000, 10000, n_days)
        }),
        'ASSET2': pd.DataFrame({
            'timestamp': timestamps,
            'open': np.random.randn(n_days) * 2 + 200,
            'high': np.random.randn(n_days) * 2 + 202,
            'low': np.random.randn(n_days) * 2 + 198,
            'close': np.random.randn(n_days) * 2 + 200,
            'volume': np.random.randint(1000, 10000, n_days)
        })
    }
    
    news_data = {'ASSET1': pd.DataFrame(), 'ASSET2': pd.DataFrame()}
    
    env = TradingEnv(
        price_data=price_data,
        news_data=news_data,
        encoder_model=None,
        use_news=False
    )
    
    # Test reset
    state, info = env.reset()
    assert state.shape == env.observation_space.shape
    
    # Test step
    action = env.action_space.sample()
    state, reward, terminated, truncated, info = env.step(action)
    
    assert state.shape == env.observation_space.shape
    assert isinstance(reward, (int, float))
    assert isinstance(terminated, (bool, np.bool_))
    assert isinstance(truncated, (bool, np.bool_))
    assert 'portfolio_value' in info


def test_config_loading():
    """Test config loading"""
    from cmm_rl.utils import load_config, save_config
    import tempfile
    import os
    
    test_config = {
        'model': {'latent_dim': 32},
        'training': {'batch_size': 16}
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        temp_path = f.name
    
    try:
        save_config(test_config, temp_path)
        loaded_config = load_config(temp_path)
        
        assert loaded_config == test_config
    finally:
        os.unlink(temp_path)


def test_helpers():
    """Test utility helpers"""
    from cmm_rl.utils import set_seed, get_device, format_currency
    
    # Test set_seed
    set_seed(42)
    r1 = np.random.random()
    set_seed(42)
    r2 = np.random.random()
    assert r1 == r2
    
    # Test get_device
    device = get_device()
    assert isinstance(device, torch.device)
    
    # Test format_currency
    assert "₹100.00" in format_currency(100)
    assert "₹1.00K" in format_currency(1000)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

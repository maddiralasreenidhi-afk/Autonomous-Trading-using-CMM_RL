# CMM-RL Test Suite

## Running Tests

```powershell
# Install test dependencies
pip install pytest pytest-cov

# Run all tests
pytest tests/

# Run with coverage
pytest tests/ --cov=cmm_rl --cov-report=html

# Run specific test
pytest tests/test_basic.py::test_price_encoder -v
```

## Test Structure

- `test_basic.py` - Basic smoke tests for all modules
- More test files can be added as needed

## Test Coverage

Current tests cover:
- Module imports
- Data fetching and dataset creation
- Model architectures (encoders)
- Trading environment
- Performance metrics
- Utility functions

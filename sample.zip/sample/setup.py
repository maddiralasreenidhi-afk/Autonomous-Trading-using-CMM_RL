"""
Setup script for CMM-RL package
"""
from setuptools import setup, find_packages

setup(
    name="cmm_rl",
    version="0.1.0",
    description="Contrastive Multi-Modal Reinforcement Learning for Trading",
    author="Your Name",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.24.0",
        "pandas>=2.0.0",
        "gymnasium>=0.29.0",
        "stable-baselines3>=2.1.0",
        "transformers>=4.30.0",
        "sentencepiece>=0.1.99",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "matplotlib>=3.7.0",
        "seaborn>=0.12.0",
        "scipy>=1.10.0",
        "pyyaml>=6.0",
        "omegaconf>=2.3.0",
        "tqdm>=4.65.0",
        "loguru>=0.7.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "jupyter>=1.0.0",
            "ipykernel>=6.25.0",
        ]
    },
)

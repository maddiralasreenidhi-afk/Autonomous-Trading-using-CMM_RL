# Quick Setup Guide for CMM-RL

This guide will help you get started with the CMM-RL trading system.

## Prerequisites

- Python 3.8 or higher
- Windows PowerShell
- Git (optional, for version control)

## Step 1: Create Virtual Environment

```powershell
# Navigate to project directory
cd "C:\Users\saich\OneDrive\Desktop\7th sem\fyp\sim"

# Create virtual environment
python -m venv .venv

# Activate virtual environment
. .\.venv\Scripts\Activate.ps1
```

## Step 2: Install Dependencies

```powershell
# Upgrade pip
python -m pip install --upgrade pip

# Install requirements
pip install -r requirements.txt
```

**Note:** The first time you run this, it will download:
- PyTorch (~2GB)
- Transformers and FinBERT model (~500MB)
- Other dependencies

This may take 10-15 minutes depending on your internet connection.

## Step 3: Configure Twelve Data API Key

```powershell
# Copy environment template
cp .env.example .env

# Edit .env file with your Twelve Data API key
notepad .env
```

Update the following in `.env`:
- `TWELVE_DATA_API_KEY`: Your Twelve Data API key

**Get your free API key:**
1. Sign up at [https://twelvedata.com/](https://twelvedata.com/)
2. Get your API key (800 calls/day on free tier)
3. Add it to `.env` file

## Step 4: Test Installation

```powershell
# Run basic tests
pytest tests/test_basic.py -v
```

## Step 5: Download Sample Data

```powershell
# Test data fetching
python -c "from cmm_rl.data import HistoricalDataFetcher; fetcher = HistoricalDataFetcher(); print(fetcher.fetch('AAPL', '2024-01-01', '2024-11-01').head())"
```

## Step 6: Train Models

### Phase 1: Contrastive Pretraining (Optional - for better performance)

```powershell
# Train contrastive encoders
python -m cmm_rl.training.train_contrastive --config .\configs\contrastive.yaml
```

This will:
- Fetch historical data for configured tickers
- Train price and news encoders
- Save checkpoints to `./checkpoints/contrastive/`

**Time:** ~2-4 hours on CPU, ~30 minutes on GPU

### Phase 2: RL Training

```powershell
# Train RL trading agent
python -m cmm_rl.rl.train_rl --config .\configs\rl.yaml
```

This will:
- Load pretrained encoders (or use random if not available)
- Train PPO agent for portfolio allocation
- Save checkpoints to `./checkpoints/rl/`

**Time:** ~1-2 hours on CPU, ~20 minutes on GPU

## Step 7: Run Backtest

```powershell
# Backtest on historical data
python .\scripts\backtest.py --start 2023-07-01 --end 2024-01-01
```

This will:
- Test the trained agent on historical data
- Generate performance metrics
- Create visualization plots

Results saved to `./outputs/backtest/`

## Step 8: Live Trading (Simulation)

```powershell
# Set environment variables
$env:TICKER="RELIANCE"
$env:USE_NEWS="true"

# Run live trading agent (uses mock feed for testing)
python .\scripts\live_infer.py
```

**Press Ctrl+C to stop**

## Troubleshooting

### Import Errors

If you see import errors:
```powershell
# Reinstall requirements
pip install -r requirements.txt --force-reinstall
```

### CUDA Errors

If you have a GPU but see CUDA errors:
```powershell
# Install PyTorch with CUDA support
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### FinBERT Download Issues

If FinBERT download fails:
```powershell
# Pre-download the model
python -c "from transformers import AutoModel; AutoModel.from_pretrained('ProsusAI/finbert')"
```

### Memory Errors

If you run out of memory during training:
- Reduce `batch_size` in config files
- Reduce `window_size` from 60 to 30
- Close other applications

## Quick Test (No Training Required)

To test the system without training:

```powershell
# Run environment test
python -m cmm_rl.rl.environment

# Run metrics test  
python -m cmm_rl.eval.metrics

# Run data fetching test
python -m cmm_rl.data.historical
```

## Project Structure

```
demo/
├── cmm_rl/              # Main package
│   ├── data/            # Data fetching modules
│   ├── models/          # Neural network models
│   ├── training/        # Training scripts
│   ├── rl/              # RL environment & training
│   ├── eval/            # Evaluation metrics
│   └── utils/           # Utility functions
├── configs/             # Configuration files
├── scripts/             # Executable scripts
├── tests/               # Test suite
├── checkpoints/         # Model checkpoints (created during training)
├── logs/                # Log files (created during execution)
└── outputs/             # Results and plots (created during evaluation)
```

## Next Steps

1. **Customize Configuration**: Edit `configs/contrastive.yaml` and `configs/rl.yaml`
2. **Add More Tickers**: Modify the `tickers` list in config files
3. **Tune Hyperparameters**: Adjust learning rates, batch sizes, etc.
4. **Extend Features**: Add technical indicators, additional news sources
5. **Deploy to Production**: Connect to real trading APIs

## Support

For issues or questions:
1. Check the logs in `./logs/` directory
2. Review error messages carefully
3. Ensure all dependencies are installed
4. Verify API keys are correct

## Performance Expectations

- **Sharpe Ratio**: Target > 1.5
- **Max Drawdown**: Target < 20%
- **Win Rate**: Target > 55%
- **Annual Return**: Target 15-25%

Results will vary based on:
- Market conditions
- Training data quality
- Hyperparameter tuning
- News data availability

## Important Notes

⚠️ **This is a research/educational project**
- Do not use with real money without thorough testing
- Past performance does not guarantee future results
- Always implement proper risk management
- Consider transaction costs and slippage

## License

MIT License - See LICENSE file

## 📂 Project Structure

```
demo/
├── cmm_rl/                          # Main Python package
│   ├── __init__.py
│   ├── data/                        # Data fetching modules
│   │   ├── __init__.py
│   │   ├── historical.py           # Historical price data
│   │   ├── live_feed.py            # Real-time WebSocket feed
│   │   └── news.py                 # News headlines & caching
│   ├── models/                      # Neural network models
│   │   ├── __init__.py
│   │   ├── price_encoder.py        # Temporal CNN for prices
│   │   ├── news_encoder.py         # FinBERT for news
│   │   └── contrastive_model.py    # Combined contrastive model
│   ├── training/                    # Training scripts
│   │   ├── __init__.py
│   │   ├── dataset.py              # Contrastive dataset
│   │   └── train_contrastive.py    # Contrastive training loop
│   ├── rl/                          # Reinforcement learning
│   │   ├── __init__.py
│   │   ├── environment.py          # Gymnasium trading env
│   │   └── train_rl.py             # PPO training script
│   ├── eval/                        # Evaluation & metrics
│   │   ├── __init__.py
│   │   ├── metrics.py              # Sharpe, Sortino, MDD, etc.
│   │   └── visualize.py            # Performance plots
│   └── utils/                       # Utility functions
│       ├── __init__.py
│       ├── config.py               # Config management
│       ├── logger.py               # Logging setup
│       └── helpers.py              # Helper functions
├── configs/                         # Configuration files
│   ├── contrastive.yaml            # Contrastive learning config
│   └── rl.yaml                     # RL training config
├── scripts/                         # Executable scripts
│   ├── live_infer.py               # Live trading agent
│   ├── backtest.py                 # Historical backtesting
│   └── generate_report.py         # Performance reporting
├── tests/                           # Test suite
│   ├── README.md
│   └── test_basic.py               # Basic smoke tests
├── checkpoints/                     # Model checkpoints (created)
├── logs/                            # Log files (created)
├── outputs/                         # Results & plots (created)
├── README.md                        # Main documentation
├── SETUP.md                         # Setup instructions
├── requirements.txt                 # Python dependencies
├── .env.example                     # Environment template
├── .gitignore                       # Git ignore rules
├── LICENSE                          # MIT License
├── verify_install.py               # Installation checker
└── quickstart.ps1                  # Quick setup script
```
